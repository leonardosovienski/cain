"""Attach a scoped completion audit without changing the tested runtime."""
import hashlib
import json
import pathlib
import shutil

B=pathlib.Path(__file__).parent
A=B/'closure-real-20260912'
O=pathlib.Path('C:/Users/leona/Documents/Codex/2026-09-12/lei/outputs')
def read(path): return json.loads(path.read_bytes())
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
r=read(A/'RESULTS.json'); m=read(A/'CANDIDATE_MANIFEST.json')
assert r['status']=='PASS_BOUNDED_REAL_DOCUMENTATION'
assert read(A/'CHECKPOINT.json')['status']=='COMPLETED'
review=pathlib.Path('C:/CAIN/work/supply-review-20260912/SUPPLEMENTAL_REAL_REVIEW.md')
assert review.exists(), 'Wait for independent review before finalizing'
shutil.copyfile(review,A/'INDEPENDENT_REVIEW.md')
rows=[]
mapping=[
 ('1–3','Retomada, precedência e baseline','PASS',['SESSION_BASELINE.md','CANDIDATE_MANIFEST.json','SOURCE_PRESERVATION.json'],'Candidato anterior preservado; identidade não é commit.'),
 ('4–7','Contratos, isolamento, fontes e plataforma','PASS',['F01_F10_MATRIX.json','FINAL_VERIFICATION.json','REMOTE_FINAL_VERIFICATION.json'],'Matriz executada por componente; runtime científico fora do escopo.'),
 ('8–11','Inventário, população retomável e cobertura','PARTIAL_JUSTIFIED',['SOURCE_INVENTORY.json','POPULATION_PLAN.json','POPULATION_LEDGER.jsonl','KNOWLEDGE_COVERAGE.json'],'Universo científico desconhecido; fontes restritas não copiadas; docs novos são republicações, não conhecimento adicional.'),
 ('12–13','Uso real e protocolo','PASS',['UTILITY_PROTOCOL.json','UTILITY_RESULTS.jsonl','MANUAL_GUIDE_REHEARSAL.json','WEB_REHEARSAL.json'],'Avaliação de engenharia; não é teste cego nem avaliação econômica.'),
 ('14–15','Runner e memória derivada','PASS',['INTERRUPTION_RELEASE.json','utility-release/CHECKPOINT.json','closure-real-20260912/RESULTS.json'],'Runner retomou 2→18; rodada suplementar finita realizou 47 chamadas e três diagnósticos reais.'),
 ('16','Comparação de benefício','INCONCLUSIVE',['derived-evaluation-r2/RESULTS.json','closure-real-20260912/PROTOCOL.json','closure-real-20260912/RESULTS.json'],'Comparação estrutural real NEUTRAL; sem evidência de generalização. O prompt aceita resultado sem ganho.'),
 ('17–19','Adversarial, correção e recuperação','PASS',['FINDINGS_AND_REMEDIATION.md','ACCEPTANCE_RESULTS.json','diagnostic-restore/RESULTS.json','closure-real-20260912/RESULTS.json'],'Contradição sintética identificada como tal; corpus real teve restart, restore offline e revogação.'),
 ('20','Identidade, instalação e gates','PASS',['GATES.json','FINAL_VERIFICATION.json','REMOTE_FINAL_VERIFICATION.json','closure-real-20260912/CANDIDATE_MANIFEST.json'],'Novo corpus tem identidade própria; CI anterior não é atribuída ao corpus suplementar.'),
 ('21–22','Handoff e referências pertinentes','PASS',['FINAL_HANDOFF.md','USER_ACCEPTANCE.md','CHECKPOINT.json'],'Não há dúvida material nova que exija pesquisa externa.'),
 ('A–C','Guia e ensaio do aceite manual','PASS',['USER_ACCEPTANCE.md','MANUAL_GUIDE_REHEARSAL.json','WEB_REHEARSAL.json'],'Ensaio técnico feito; não representa experiência ou aprovação pessoal de Leo.'),
 ('D','Runner reproduzível e finito','PASS',['UTILITY_PROTOCOL.json','INTERRUPTION_RELEASE.json','utility-release/CHECKPOINT.json'],'Nenhum scheduler; caps do runner não devem ser confundidos com verificações pós-operação do harness suplementar.'),
 ('E','Demonstrações, autoria e modelo real','INCONCLUSIVE',['MODEL_VERIFICATION.json','MODEL_VERIFICATION_RECEIPTS.json','closure-real-20260912/RESULTS.json'],'Modelo real executado; síntese não certificada. Exemplo desfavorável preservado.'),
 ('F–G','Admissões, limites e encerramento','PASS',['ADMISSION_REQUESTS.json','closure-real-20260912/AUTHORIZATION.json','FINAL_HANDOFF.md'],'Autorização suplementar limitada às publicações novas dos docs de três fontes; demais restrições preservadas.')]
for section,purpose,status,files,limit in mapping:
    assert all((B/f).is_file() for f in files), files
    rows.append(dict(section=section,purpose=purpose,status=status,
                     evidence={f:sha(B/f) for f in files},limit=limit))
stock_receipts=read(B/'MODEL_VERIFICATION_RECEIPTS.json')
stock=next(json.loads(x['stdout']) for x in stock_receipts if 'stocks' in x['command'])
demo=dict(actor='CODEX selects verbatim CAIN receipts; no new CAIN-generated text',
    structural=[dict(collection=d,question='Quantos documentos e relações estão representados?',
                     actual_cain_assertion=x['actual'],derivation_id=x['diagnostic']['diagnostics'][0]['derivation_id'],
                     bundle_id=x['bundle_id']) for d,x in r['collections'].items()],
    real_model_negative_example=dict(domain='stocks',actual_cain_output=stock['explanation'],
        assessment_by='CODEX',assessment='The synthesis changes a domain readiness statement into a statement about an individual. Literal quotation was valid; that interpretation is not certified.'),
    limits=dict(reserved_followup='Not executed as a distinct semantic product question; do not count it as validation or generalization.',
                contradiction='Previously tested with synthetic fixture only; no real contradiction was manufactured.'))
(A/'DEMONSTRATIONS.json').write_text(json.dumps(demo,ensure_ascii=False,indent=2),encoding='utf-8')
report=f'''# Fechamento do primeiro prompt

A execução de engenharia solicitada foi concluída no escopo admissível. O prompt original aceita cobertura parcial justificada e ausência de ganho de memória; pede prontidão para revisão de congelamento, não implantação nem um aceite pessoal inventado.

## Trabalho adicional executado

- Autorização desta continuação registrada antes da execução, com hashes específicos dos documentos. Novas publicações locais de Core, Ops e Ecosystem; os seis bundles anteriores e sua política foram preservados.
- 33 documentos reais já admitidos: Core 16, Ops 11 e Ecosystem 6. São republicações autorizadas para este ensaio, não 33 fontes novas nem novos experimentos.
- 47 chamadas à CLI instalada: aprovação, importação e duplicata; consulta factual; diagnóstico persistido; nova leitura em outro processo; comparação com manifestos dos produtores; backup, restore offline e revogação.
- Resultado comparativo **NEUTRAL**: as contagens coincidiram, sem ganho de informação. Revogar geração bloqueou os diagnósticos e preservou a leitura factual.
- Código instalado e fontes originais preservados. Identidade suplementar: `{m['supplemental_id']}`. Recibos em `C:/CAIN/work/supply-final-20260912/closure-real-20260912`.

## Limites que não viram PASS artificial

O ensaio suplementar ocorreu no Windows. O CI Linux continua vinculado ao código e ao acervo previamente registrados; não é evidência de execução deste novo lote no Linux. A revisão independente desta rodada está em `INDEPENDENT_REVIEW.md` no diretório de evidências.

A comparação real mede recuperação de contagens estruturais. Não demonstra qualidade semântica, generalização nem aprendizado. A pergunta semântica reservada no protocolo não foi executada como pergunta distinta no produto. A contradição continua sendo evidência sintética da rodada anterior. Os limites do harness suplementar são verificações entre operações e após captura, não quotas rígidas durante toda escrita; o runner anterior tem seu próprio controle de recursos. RAM de pico permanece desconhecida.

As três inferências locais anteriores e o timeout foram preservados. A síntese Stocks contém uma interpretação sobre indivíduo não estabelecida pela fonte; não se recomenda utilizá-la como conclusão confiável. `DEMONSTRATIONS.json` contém saídas reais e esse exemplo desfavorável, separado do roteiro de perguntas sem respostas.

## O que significa concluído

Os passos aplicáveis do mandato têm evidências identificadas em `REQUIREMENT_AUDIT.json`. Cobertura de fontes não admitidas e utilidade semântica geral continuam limitadas; não são promessas de trabalho rodando. O preview permanece **LIMITED_IN_STAGING** e o candidato base está pronto para revisão de congelamento no escopo documentado.

Seu uso pessoal permanece uma etapa sua. Eu executei o ensaio técnico do guia; não marquei sua satisfação ou aprovação como se você tivesse testado. Congelamento administrativo, release e implantação não são requisitos concluídos por inferência: o primeiro prompt termina em revisão de congelamento.

Nenhum serviço ou scheduler foi iniciado nesta continuação. Para usar o produto, consulte [USER_ACCEPTANCE.md](USER_ACCEPTANCE.md). Para evidências e reconstrução, consulte [FINAL_HANDOFF.md](FINAL_HANDOFF.md).
'''
(B/'FECHAMENTO_DO_PROMPT.md').write_text(report,encoding='utf-8')
handoff=(B/'FINAL_HANDOFF.md').read_text(encoding='utf-8')
marker='<!-- supplemental-real-closure -->'
if marker not in handoff:
    first,rest=handoff.split('\n',1)
    handoff=first+'\n\n'+marker+f'''\n**Atualização de fechamento:** houve uma rodada adicional com 33 documentos reais de Core/Ops/Ecosystem, 47 chamadas públicas e comparação estrutural neutra. Persistência, restore offline e revogação passaram. São novas publicações autorizadas em acervo separado, identidade `{m['supplemental_id']}`; a identidade/CI do candidato base abaixo foi preservada. Consulte `FECHAMENTO_DO_PROMPT.md` e `closure-real-20260912/RESULTS.json`. As menções abaixo aos seis bundles que negam geração referem-se ao acervo original.\n'''+rest
(B/'FINAL_HANDOFF.md').write_text(handoff,encoding='utf-8')
guide=(B/'USER_ACCEPTANCE.md').read_text(encoding='utf-8')
if marker not in guide:
    guide+=f'''\n\n{marker}\n## Ensaio adicional: diagnósticos reais autorizados\n\nO acervo suplementar usa o mesmo Python instalado e tem identidade `{m['supplemental_id']}`. Os documentos de `core`, `ops` e `ecosystem` foram republicados para análise estrutural local. É um acervo separado; não substitui o roteiro original. Comando já exercitado (troque somente a coleção para alternar):\n\n```powershell\n& 'C:/CAIN/work/supply-final-20260912/venv/Scripts/python.exe' -m cain research --db 'C:/CAIN/work/supply-final-20260912/closure-real-20260912/staging/research.db' --policy 'C:/CAIN/work/supply-final-20260912/closure-real-20260912/staging/policy.json' --user leo --collection core bundle diagnostics\n```\n\nEncerra sozinho. O resultado é uma contagem estrutural rastreável, não interpretação por modelo. O restore usado para testar revogação está em outra pasta e intencionalmente nega geração.\n'''
(B/'USER_ACCEPTANCE.md').write_text(guide,encoding='utf-8')
g=read(B/'GATES.json')
g['supplemental_real_derivation']=dict(status=r['status'],comparison='NEUTRAL',identity=m['supplemental_id'],
    corpus='33 previously admitted authored documents in three new publications',platform='Windows only for this supplemental corpus',
    review='closure-real-20260912/INDEPENDENT_REVIEW.md',default_enabled=False)
g['derived_scope']='Original six bundles retain generation restrictions. Three newly authorized documentation publications passed real structural comparison, restart/offline restore and revocation. Neutral count recovery is not demonstrated learning or generalization.'
(B/'GATES.json').write_text(json.dumps(g,indent=2),encoding='utf-8')
c=read(B/'CHECKPOINT.json')
c['supplemental']=dict(status='COMPLETED',identity=m['supplemental_id'],calls=47,evidence_root=str(A))
c['pending']=['Optional personal user feedback and administrative freeze decision; not an unexecuted engineering test',
              'Broader source admission or semantic-benefit research is outside the completed bounded evaluation']
c['clarification']='Original prompt permits partial justified coverage and non-positive/inconclusive benefit; neither is silently upgraded.'
(B/'CHECKPOINT.json').write_text(json.dumps(c,indent=2),encoding='utf-8')
# Refresh evidence hashes only for documents changed by this audit, never change a test oracle.
for row in rows:
    row['evidence']={f:sha(B/f) for f in row['evidence']}
(A/'REQUIREMENT_AUDIT.json').write_text(json.dumps(dict(requirements=rows,scope='Document-level evidence mapping; not a new test run or claim of complete scientific coverage'),ensure_ascii=False,indent=2),encoding='utf-8')
for name in ('FECHAMENTO_DO_PROMPT.md','FINAL_HANDOFF.md','USER_ACCEPTANCE.md','GATES.json','CHECKPOINT.json'):
    shutil.copyfile(B/name,O/name)
for name in ('REQUIREMENT_AUDIT.json','DEMONSTRATIONS.json','INDEPENDENT_REVIEW.md'):
    shutil.copyfile(A/name,O/name)
(O/'CONTINUACAO_EXECUTADA.md').write_text('# Continuidade\n\nLeia [o fechamento do primeiro prompt](FECHAMENTO_DO_PROMPT.md), [o guia manual](USER_ACCEPTANCE.md) e [o handoff](FINAL_HANDOFF.md).\n',encoding='utf-8')
(B/'DELIVERY_INDEX.json').write_text(json.dumps({p.name:sha(p) for p in B.iterdir() if p.is_file() and p.name!='DELIVERY_INDEX.json'},indent=2),encoding='utf-8')
print(json.dumps(dict(status='COMPLETE_WITH_EXPLICIT_LIMITS',supplemental_id=m['supplemental_id'],outputs=str(O))))
