"""Manual staging entry; Ctrl+C stops only this foreground server."""
from pathlib import Path
import argparse
import uvicorn
from cain.api import create_app
B=Path(__file__).parent
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--legacy',action='store_true');args=parser.parse_args()
 research=B/('model' if args.legacy else 'staging')
 app=create_app(db_path=B/'staging/workspace.db',config_path=B/'web.toml',
                research_policy=research/'policy.json',research_db=research/'research.db')
 uvicorn.run(app,host='127.0.0.1',port=8889)
