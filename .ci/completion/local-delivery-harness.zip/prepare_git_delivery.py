"""Organize source and durable continuity; private corpus stays in its original locations."""
import hashlib
import json
import pathlib
import shutil
import zipfile

B=pathlib.Path(__file__).parent
P=pathlib.Path('C:/CAIN/work/supply-publish-20260912')
H=pathlib.Path('C:/CAIN/entregas/supply-20260912')
O=pathlib.Path('C:/Users/leona/Documents/Codex/2026-09-12/lei/outputs')
D=P/'docs/supply'
D.mkdir(exist_ok=True)
H.mkdir(exist_ok=True)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((B/'CANDIDATE_MANIFEST.json').read_bytes())
attrs=P/'.gitattributes'
text=attrs.read_text(encoding='utf-8')
marker='# Exact Supply runtime bytes; candidate manifest includes line endings.'
if marker not in text:
    text+='\n'+marker+'\n'
    text+='\n'.join('/'+name+' -text' for name in m['identity_payload']['overlay_files']
                    if name.startswith(('src/','evaluation/','tests/')) or name=='pyproject.toml')+'\n'
    text+='/docs/supply/evidence/* -text\n/.ci/completion/local-delivery-harness.zip -text\n'
    attrs.write_text(text,encoding='utf-8')

files=['FINAL_HANDOFF.md','USER_ACCEPTANCE.md','FECHAMENTO_DO_PROMPT.md','FINDINGS_AND_REMEDIATION.md']
for name in files:
    shutil.copyfile(B/name,D/name)
    shutil.copyfile(B/name,H/name)
evidence=D/'evidence'
evidence.mkdir(exist_ok=True)
for name in ['CANDIDATE_MANIFEST.json','F01_F10_MATRIX.json','GATES.json','CHECKPOINT.json',
             'DELIVERY_REVIEW.md','RE_REVIEW_FINAL.md','dependencies.txt','INTERRUPTION_RELEASE.json']:
    shutil.copyfile(B/name,evidence/name)
for name in ['CANDIDATE_MANIFEST.json','PROTOCOL.json','AUTHORIZATION.json','INDEPENDENT_REVIEW.md']:
    # Metadata and review only. No received document bytes, model outputs, or database are published.
    shutil.copyfile(B/'closure-real-20260912'/name,evidence/('supplemental-'+name))

scripts=sorted(B.glob('*.py'))
with zipfile.ZipFile(P/'.ci/completion/local-delivery-harness.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in scripts:
        z.write(p,p.name)
    for name in ['populate.py','baseline.py','prepare_utility.py']:
        source=pathlib.Path('C:/CAIN/work/supply-preview-20260912')/name
        z.write(source,'historical-preview/'+name)

layout=dict(schema='cain-local-delivery-layout/1',source_checkout=str(P),branch='validation/cain-supply-completion-20260912',
    base_candidate=m['candidate_id'],local_delivery=str(H),evidence_root=str(B),
    installed_python=str(B/'venv/Scripts/python.exe'),
    source_rules='Only CAIN delivery files committed. Original producer checkouts and active CAIN instance preserved.',
    retained_local=[dict(path=str(B/'staging'),purpose='Six original Bundle collections, policy and CAS'),
                    dict(path=str(B/'model'),purpose='Legacy factual web corpus and preserved model history'),
                    dict(path=str(B/'closure-real-20260912'),purpose='Supplemental authorized documentation corpus and receipts'),
                    dict(path=str(B/'backup'),purpose='Consistent original staging backup'),
                    dict(path=str(B/'venv'),purpose='Installed noneditable runtime'),
                    dict(path='C:/CAIN/work/supply-review-20260912',purpose='Independent reviews'),
                    dict(path='C:/CAIN/work/supply-preview-20260912',purpose='Preserved predecessor evidence'),
                    dict(path='C:/CAIN/work/supply-completion-20260912',purpose='Preserved previous model work')],
    excludes_from_remote='Databases, CAS/received objects, private model outputs, model weights, environments and full local logs remain local. Source-specific non-disclosure restrictions are preserved.',
    harness_archive='.ci/completion/local-delivery-harness.zip',
    harness_limit='Historical finite scripts have fixed paths and some create-only destinations. Read their headers/arguments; do not batch rerun or regenerate old reports over later evidence.',
    old_collectors='collect_final.py verifies f0cfb92 deliberately; it is a historical receipt collector, not a current-HEAD verifier.',
    source_materialization='Current branch source is populated from the verified overlay. Older commit f0cfb92 had baseline source plus overlay only.')
for root in [D,H]:
    (root/'LOCAL_LAYOUT.json').write_text(json.dumps(layout,ensure_ascii=False,indent=2),encoding='utf-8')
readme='''# CAIN Supply — retomar sem o chat

Esta é a entrada atual da entrega de engenharia. A branch é `validation/cain-supply-completion-20260912`; o checkout local é `C:/CAIN/work/supply-publish-20260912`. O código final agora está diretamente em `src/`, além do overlay preservado. Não usar `main` ou a instalação ativa como substitutos deste candidato.

Leia [o fechamento](FECHAMENTO_DO_PROMPT.md), [o guia de uso](USER_ACCEPTANCE.md) e [o handoff de evidências](FINAL_HANDOFF.md). O mapa [LOCAL_LAYOUT.json](LOCAL_LAYOUT.json) identifica pastas, bancos, políticas, ambiente e histórico. A pasta de entrega local é `C:/CAIN/entregas/supply-20260912`.

## Estado e limites

Base `d00bbc6fb910b3c51be6720d21012f4655258468adb7d7335451974929c58752`, código instalado `7da108d0172b7ccc2675404b7dbf0b8a21ad248ee814ea14f199225003d23861`. Windows: 575 aprovados e um skip de privilégio. Linux 3.11–3.14: 574 aprovados e dois skips exclusivos do Windows por versão; evidência anterior em [CI do candidato](https://github.com/leonardosovienski/cain/actions/runs/34702803998).

A rodada suplementar local possui identidade `3f3b34cf116201aea601459668b70480570fa9583575e727228e75fd0c2a8063`: 33 documentos reais de três fontes, 47 chamadas, persistência/restore/revogação aprovados e comparação estrutural neutra. Não é ganho de aprendizado. Qualidade semântica do modelo continua inconclusiva; fontes restritas não foram liberadas por conveniência.

Pronto para revisão de congelamento da engenharia delimitada; preview limitado em staging. Não houve merge, release, implantação ou alteração da instância ativa. Seu aceite pessoal não foi presumido.

## Abrir e encerrar

```powershell
& 'C:/CAIN/work/supply-final-20260912/venv/Scripts/python.exe' 'C:/CAIN/work/supply-final-20260912/web_preview.py' --legacy
```

Abra `http://127.0.0.1:8889`; encerre com Ctrl+C nesse terminal. O guia contém consultas CLI e seus scopes. Nenhum serviço é iniciado automaticamente por esta organização.

## Reconstrução e continuidade

O Git contém código, testes, recursos empacotados, workflows, manifestos, documentação e um arquivo dos scripts locais em `.ci/completion/local-delivery-harness.zip`. O arquivo de scripts é material de reprodução/consulta, não um instalador nem uma ordem para executar tudo. Os scripts históricos criam destinos exclusivos e alguns verificam commits antigos intencionalmente.

Bancos, objetos recebidos, pesos de modelos, ambientes e saídas privadas permanecem nas pastas originais indicadas no inventário. Não presumir que um clone do Git recupera esse conteúdo. Para recuperar o acervo, use os backups e o procedimento de archive restore registrados no handoff, em destino novo. Não remover as pastas históricas ou reais para "limpar" a máquina.

As referências a branches, ausência de Linux ou instalação nos relatórios anteriores são históricas. O recibo local `GIT_DELIVERY.json` registra o commit final e a conferência remota desta publicação; os relatórios de testes permanecem vinculados aos respectivos commits/candidatos. Novas alterações exigem nova identidade e validação pertinente.

Para continuar: leia esta entrada, confira `git status`, `git rev-parse HEAD` e `git ls-remote origin refs/heads/validation/cain-supply-completion-20260912`, preserve alterações encontradas e use o candidato/ambiente indicado. Não misture commits dos produtores com este repositório consumidor.
'''
(D/'README.md').write_text(readme,encoding='utf-8')
(H/'LEIA_PRIMEIRO.md').write_text(readme,encoding='utf-8')
for name in ['README.md','CONTINUIDADE.md','ESTADO_DO_PROJETO.md','PUBLICATION_STATUS_20260912.md','docs/README.md']:
    p=P/name
    content=p.read_text(encoding='utf-8')
    link='supply/README.md' if name.startswith('docs/') else 'docs/supply/README.md'
    notice=f'<!-- SUPPLY-GIT-DELIVERY-20260912 -->\n**Continuidade atual desta branch:** [CAIN Supply — entrega e retomada]({link}). Código final materializado na árvore normal; candidato pronto para revisão de congelamento delimitada, sem implantação. As notas anteriores abaixo são históricas e não descrevem o novo checkout.\n<!-- /SUPPLY-GIT-DELIVERY-20260912 -->\n'
    if '<!-- SUPPLY-GIT-DELIVERY-20260912 -->' not in content:
        first,rest=content.split('\n',1)
        p.write_text(first+'\n\n'+notice+'\n'+rest,encoding='utf-8')
p=P/'.ci/completion/README.md'
content=p.read_text(encoding='utf-8').replace('The branch root retains the baseline source; cain-overlay.zip contains the candidate\nruntime.', 'At the historical tested commit below, the branch root retained baseline source.\nThe current branch also materializes that exact candidate directly in src/.\ncain-overlay.zip preserves the original candidate runtime.')
p.write_text(content,encoding='utf-8')
notice='''\n\n## Atualização Git e pastas\n\nO código final foi materializado no checkout `C:/CAIN/work/supply-publish-20260912`, branch `validation/cain-supply-completion-20260912`. As descrições de raiz baseline acima registram a etapa anterior. Leia `C:/CAIN/entregas/supply-20260912/LEIA_PRIMEIRO.md`; `GIT_DELIVERY.json` nessa pasta registra o commit e a conferência remota. Os dados e evidências locais permanecem em `C:/CAIN/work/supply-final-20260912`. Nenhuma instância ativa foi modificada.\n'''
for target in [B/'FINAL_HANDOFF.md',D/'FINAL_HANDOFF.md',H/'FINAL_HANDOFF.md']:
    content=target.read_text(encoding='utf-8')
    if '## Atualização Git e pastas' not in content:
        target.write_text(content+notice,encoding='utf-8')
cmd='@echo off\r\ncd /d "C:\\CAIN\\work\\supply-final-20260912"\r\n"C:\\CAIN\\work\\supply-final-20260912\\venv\\Scripts\\python.exe" "C:\\CAIN\\work\\supply-final-20260912\\web_preview.py" --legacy\r\n'
(H/'ABRIR_PREVIEW.cmd').write_bytes(cmd.encode('ascii'))
for name in files:
    shutil.copyfile(B/name,O/name)
shutil.copyfile(H/'LEIA_PRIMEIRO.md',O/'LEIA_PRIMEIRO.md')
print(json.dumps(dict(status='PREPARED',local_hub=str(H),scripts=len(scripts))))
