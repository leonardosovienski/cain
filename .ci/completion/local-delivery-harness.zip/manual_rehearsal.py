import json,pathlib,subprocess
B=pathlib.Path(__file__).parent;PY=B/'venv/Scripts/python.exe'
commands=[('crypto','query',['--entity-type','hypothesis','--limit','50']),('crypto','lineage',['--limit','50']),('brasileirao','query',['--entity-type','claim','--limit','50']),('brasileirao','artifacts',['--limit','50']),('stocks','query',['--entity-type','dataset','--limit','50']),('stocks','artifacts',['--limit','50']),('core','query',['--entity-type','document','--limit','50']),('core','lineage',['--limit','50']),('ops','query',['--entity-type','document','--limit','50']),('ops','artifacts',['--limit','50']),('ecosystem','query',['--entity-type','document','--limit','50']),('ecosystem','lineage',['--limit','50'])]
rows=[];candidate=json.loads((B/'CANDIDATE_MANIFEST.json').read_bytes())['candidate_id']
for domain,action,args in commands:
 command=[str(PY),str(B/'preview.py'),'--collection',domain,action,*args]
 r=subprocess.run(command,cwd=B,capture_output=True,timeout=60);assert r.returncode==0,r.stderr
 rows.append(dict(candidate=candidate,command=command,actual=json.loads(r.stdout),returncode=0))
(B/'MANUAL_GUIDE_REHEARSAL.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
print('PASS_12_EXACT_GUIDE_COMMANDS')
