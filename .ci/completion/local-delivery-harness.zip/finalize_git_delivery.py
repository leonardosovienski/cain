"""Verify publication, archive source, and write local final receipt after the last commit."""
import hashlib
import json
import pathlib
import shutil
import subprocess
import urllib.request

B=pathlib.Path(__file__).parent
P=pathlib.Path('C:/CAIN/work/supply-publish-20260912')
H=pathlib.Path('C:/CAIN/entregas/supply-20260912')
O=pathlib.Path('C:/Users/leona/Documents/Codex/2026-09-12/lei/outputs')
runtime='f1f1f5632fe5b6856c31abf6d96c4f0af5780004'
branch='validation/cain-supply-completion-20260912'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(P),*args],text=True).strip()
head=git('rev-parse','HEAD')
remote=git('ls-remote','origin','refs/heads/'+branch).split()[0]
assert head==remote and git('status','--porcelain')=='', 'Unpublished or dirty checkout'
changes=git('diff','--name-only',runtime,head).splitlines()
assert all(x.startswith(('docs/','.ci/completion/')) for x in changes), changes
manifest=json.loads((B/'CANDIDATE_MANIFEST.json').read_bytes())
checked={}
for name,digest in manifest['identity_payload']['overlay_files'].items():
    if name.startswith(('src/','evaluation/','tests/')) or name=='pyproject.toml':
        data=subprocess.check_output(['git','-C',str(P),'show','HEAD:'+name])
        assert hashlib.sha256(data).hexdigest()==digest, name
        checked[name]=digest
runs=[]
for run_id in (34704404633,34704404603):
    request=urllib.request.Request('https://api.github.com/repos/leonardosovienski/cain/actions/runs/'+str(run_id),headers={'User-Agent':'CAIN-delivery-verification'})
    with urllib.request.urlopen(request,timeout=30) as response:
        run=json.load(response)
    assert run['head_sha']==runtime and run['conclusion']=='success', run_id
    runs.append({k:run[k] for k in ('id','name','head_sha','status','conclusion','html_url')})
source=H/('cain-source-'+head[:12]+'.zip')
subprocess.run(['git','-C',str(P),'archive','--format=zip','--output',str(source),'HEAD'],check=True)
receipt=dict(status='COMMITTED_PUSHED_VERIFIED',branch=branch,local_head=head,remote_head=remote,
             validated_runtime_commit=runtime,post_validation_changes=changes,ci=runs,
             git_runtime_bytes_verified=checked,source_archive=str(source),source_archive_sha256=sha(source),
             local_hub=str(H),workspace=str(P),evidence_root=str(B),working_tree='CLEAN',
             windows_current_tree=dict(passed=513,skipped=1,scope='CAIN repository tests; original 575 count also included shared Bundle tests',xml_sha256=sha(B/'GIT_TREE_WINDOWS.xml')),
             local_data='Original databases/CAS/models and private received content retained at paths listed in LOCAL_LAYOUT.json; not published to GitHub',
             publication_scope='Validation branch only; no merge, tag, release or deployment',
             note='CI is attached to the runtime commit; later handoff/receipt-only commit is explicitly distinguished.')
for root in (B,H,O):
    (root/'GIT_DELIVERY.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
publication=P/'docs/supply/PUBLICACAO.md'
for target in (H/'PUBLICACAO.md',O/'PUBLICACAO.md'):
    shutil.copyfile(publication,target)
readme=(H/'LEIA_PRIMEIRO.md').read_text(encoding='utf-8')
readme+='\n\n## Recibo final desta entrega\n\nCommit local/remoto: `'+head+'`. CI validou o runtime em `'+runtime+'`; o commit posterior registra somente continuidade. Conferência em `GIT_DELIVERY.json`. Cópia do código disponível em `'+source.name+'`; dependências e wheel do candidato instalado estão em `pacotes/`.\n'
(H/'LEIA_PRIMEIRO.md').write_text(readme,encoding='utf-8')
shutil.copyfile(H/'LEIA_PRIMEIRO.md',O/'LEIA_PRIMEIRO.md')
for path in (B/'CHECKPOINT.json',O/'CHECKPOINT.json',H/'evidencias/CHECKPOINT.json'):
    c=json.loads(path.read_bytes())
    c.update(remote=head,publication_receipt=str(H/'GIT_DELIVERY.json'),publication_status='COMMITTED_PUSHED_VERIFIED')
    path.write_text(json.dumps(c,indent=2),encoding='utf-8')
for target in (B/'FINAL_HANDOFF.md',H/'FINAL_HANDOFF.md',O/'FINAL_HANDOFF.md'):
    s=target.read_text(encoding='utf-8')
    s+='\n\nPublicação final conferida: `'+head+'` em `'+branch+'`. Árvore limpa, SHA remoto igual ao local. Recibo completo: `C:/CAIN/entregas/supply-20260912/GIT_DELIVERY.json`.\n'
    target.write_text(s,encoding='utf-8')
(O/'CONTINUACAO_EXECUTADA.md').write_text('# Retomada sem chat\n\nLeia [LEIA_PRIMEIRO.md](LEIA_PRIMEIRO.md), com pastas, código, comandos, limitações e o recibo final de publicação. O material original continua preservado em C:/CAIN/work/supply-final-20260912.\n',encoding='utf-8')
(H/'SHA256SUMS.json').write_text(json.dumps({p.relative_to(H).as_posix():sha(p) for p in H.rglob('*') if p.is_file() and p.name!='SHA256SUMS.json'},indent=2),encoding='utf-8')
(B/'DELIVERY_INDEX.json').write_text(json.dumps({p.name:sha(p) for p in B.iterdir() if p.is_file() and p.name!='DELIVERY_INDEX.json'},indent=2),encoding='utf-8')
print(json.dumps(dict(status=receipt['status'],head=head,runtime=runtime,source_archive=str(source),verified_runtime_files=len(checked))))
