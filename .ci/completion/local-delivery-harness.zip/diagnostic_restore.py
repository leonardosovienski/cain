import json,pathlib,subprocess,sys
from cain.workspace import WorkspaceStore
B=pathlib.Path(__file__).parent;A=B/'diagnostic-restore';A.mkdir(exist_ok=False)
sys.path.insert(0,str(B/'candidate/tests'))
from test_research_bundle import setup
bundle,scope,b,root,policy_path,policy=setup.__wrapped__(A/'fixture')
WorkspaceStore(A/'fixture/workspace.db')
PY=B/'venv/Scripts/python.exe';rows=[]
def run(*args):
 command=[str(PY),'-m','cain',*map(str,args)];r=subprocess.run(command,cwd=A,capture_output=True,timeout=60)
 rows.append(dict(command=command,returncode=r.returncode,stdout=r.stdout.decode(),stderr=r.stderr.decode()));assert r.returncode==0,rows[-1]
 return json.loads(r.stdout)
def cli(area,*args):return run('research','--db',area/'research.db','--policy',area/'policy.json','--user','test','--collection','a','bundle',*args)
cli(A/'fixture','import','one/bundle.json');created=cli(A/'fixture','diagnose')
run('archive','backup','--workspace',A/'fixture/workspace.db','--research',A/'fixture/research.db','--policy',policy_path,A/'backup')
run('archive','restore',A/'backup',A/'restored')
# Only this explicitly disposable synthetic fixture is moved; real sources are untouched.
assert root.resolve().is_relative_to(A.resolve())
destination=root.with_name('synthetic-inputs-unavailable')
assert destination.resolve().is_relative_to(A.resolve())
root.rename(destination)
recovered=cli(A/'restored','diagnostics');assert recovered==created
(A/'RESULTS.json').write_text(json.dumps(dict(status='PASS',synthetic=True,offline=True,persisted_derivation_id=created['diagnostics'][0]['derivation_id'],receipts=rows),indent=2))
print('PASS_DIAGNOSTIC_OFFLINE_RESTORE')
