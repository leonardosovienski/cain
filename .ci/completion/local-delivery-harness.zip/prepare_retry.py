import pathlib,shutil,subprocess
B=pathlib.Path(__file__).parent;M=B/'model-retry';M.mkdir(exist_ok=True)
for name in ('policy.json','brasileirao-query.json'):
 shutil.copyfile(B/'model'/name,M/name)
subprocess.run([str(B/'venv/Scripts/python.exe'),'-m','cain','research','--db',str(B/'model/research.db'),'--policy',str(B/'model/policy.json'),'backup',str(M/'before.db')],check=True)
subprocess.run([str(B/'venv/Scripts/python.exe'),'-m','cain','research','restore',str(M/'before.db'),str(M/'research.db')],check=True)
s=(B/'model/real_model.py').read_text(encoding='utf-8').replace("('crypto','stocks','brasileirao')", "('brasileirao',)").replace('timeout = 90.0','timeout = 180.0').replace('timeout=90,','timeout=180,').replace('timeout=105','timeout=195').replace('max_calls=3','max_calls=1')
(M/'real_model.py').write_text(s,encoding='utf-8')
