import json,pathlib,hashlib,subprocess,sys,zipfile,xml.etree.ElementTree as ET
from cain.evaluation.resources import installed_identity
B=pathlib.Path(__file__).parent;P=pathlib.Path('C:/CAIN/work/supply-preview-20260912');PY=B/'venv/Scripts/python.exe'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
manifest=json.loads((B/'CANDIDATE_MANIFEST.json').read_bytes());body=manifest['identity_payload']
assert sha(json.dumps(body,sort_keys=True,separators=(',',':')).encode())==manifest['candidate_id']
assert sha((B/'runner.py').read_bytes())==body['runner_sha256']
assert installed_identity()['source_tree_sha256']==body['installed_code_identity']
for f,h in body['overlay_files'].items():assert sha((B/'candidate'/f).read_bytes())==h
assert sha((B/'wheels/cain_research-0.4.7-py3-none-any.whl').read_bytes())==body['wheel_sha256']
preservation=[]
for r in json.loads((P/'BASELINE.json').read_bytes())['repositories']:
 root=pathlib.Path(r['root']);head=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD']).decode().strip();status=subprocess.check_output(['git','-C',str(root),'status','--porcelain']).decode()
 checks={p:sha((root/p).read_bytes())==h for p,h in r['tracked_hashes'].items()}
 preservation.append(dict(repository=r['repository'],head_unchanged=head==r['head'],status_unchanged=status==r['status'],selected_hashes_unchanged=all(checks.values()),checked_files=len(checks)))
assert all(all(r[k] for k in ('head_unchanged','status_unchanged','selected_hashes_unchanged')) for r in preservation)
(B/'SOURCE_PRESERVATION.json').write_text(json.dumps(preservation,indent=2))
first=json.loads((B/'INTERRUPTION_RELEASE.json').read_bytes());last=json.loads((B/'utility-release/CHECKPOINT.json').read_bytes())
assert first['status']=='CANCELLED' and len(first['completed'])==2 and last['status']=='COMPLETED' and len(last['completed'])==18
assert all(last['completed'][k]==v for k,v in first['completed'].items())
for row in last['completed'].values():assert sha((B/'utility-release'/row['result']).read_bytes())==row['sha256']
def junit(path):
 suites=list(ET.parse(path).iter('testsuite'));return {k:sum(int(s.get(k,0)) for s in suites) for k in ('tests','failures','errors','skipped')}
matrix={}
for v in ('3.11','3.12','3.13','3.14'):
 area=B/('linux-'+v);complete=json.loads((area/'EXECUTION_COMPLETE.json').read_bytes());assert complete['candidate_id']==json.loads((B/'ci-kit/CANDIDATE_MANIFEST.json').read_bytes())['candidate_id']
 full=junit(area/'full.xml');targeted=junit(area/'targeted.xml');assert full['failures']==full['errors']==0;assert targeted['failures']==targeted['errors']==targeted['skipped']==0
 skips={t.get('name') for t in ET.parse(area/'full.xml').iter('testcase') if t.find('skipped') is not None}
 assert skips=={'test_api_launcher_does_not_prepare_ollama','test_windows_launcher_refuses_other_service_without_stopping_it'}
 windows_cases={t.get('name'):t for t in ET.parse(B/'WINDOWS_FINAL.xml').iter('testcase')}
 assert all(len(windows_cases[name])==0 for name in skips)
 matrix[v]=dict(full=full,targeted=targeted,mini_audit=junit(area/'mini-audit.xml'),completion=complete)
receipts=[]
def run(command):
 r=subprocess.run(list(map(str,command)),cwd=B,capture_output=True,timeout=60);receipts.append(dict(command=list(map(str,command)),returncode=r.returncode,stdout=r.stdout.decode(),stderr=r.stderr.decode()));assert r.returncode==0,receipts[-1];return json.loads(r.stdout)
M=B/'model-retry'
def recall(domain,entry,db,policy):return run([PY,'-m','cain','research','--db',db,'--policy',policy,'--collection',domain,'recall',entry])
generated=[]
for parent in (B/'model',M):
 for r in json.loads((parent/'MODEL_RESULTS.json').read_bytes()):
  if r['returncode']!=0:continue
  value=json.loads(r['stdout']);assert value['status']=='generated' and value['generation']['simulation'] is False
  for quote in value['explanation']['source_quotes']:assert quote['quote'] in quote['support']['text']
  generated.append(dict(domain=r['case']['domain'],response_id=value['response_id'],generation=value['generation'],model_synthesis=value['explanation']['proposed_synthesis']))
assert len(generated)==3
run([PY,'-m','cain','research','--db',M/'research.db','--policy',M/'policy.json','backup',B/'model-final-backup.db'])
run([PY,'-m','cain','research','restore',B/'model-final-backup.db',B/'model-final-restored.db'])
for row in generated:
 original=recall(row['domain'],row['response_id'],M/'research.db',M/'policy.json')
 restored=recall(row['domain'],row['response_id'],B/'model-final-restored.db',M/'policy.json');assert original==restored
revoked=json.loads((M/'policy.json').read_bytes());revoked['grants']=[g for g in revoked['grants'] if g['collection']!='crypto'];rp=B/'revoked-model-policy.json';rp.write_text(json.dumps(revoked))
crypto=next(r for r in generated if r['domain']=='crypto')
redacted=recall('crypto',crypto['response_id'],B/'model-final-restored.db',rp);assert redacted['status']=='history_redacted_by_current_policy'
(B/'MODEL_VERIFICATION_RECEIPTS.json').write_text(json.dumps(receipts,indent=2))
(B/'MODEL_VERIFICATION.json').write_text(json.dumps(dict(generated=generated,restore_and_restart=True,revocation=redacted,quality='Exact quotes passed; synthesis not semantically certified. Stocks synthesis introduces an individual not established by the source; do not use as recommendation.',failed_attempts=1),ensure_ascii=False,indent=2),encoding='utf-8')
result=dict(candidate_id=manifest['candidate_id'],identity='PASS',windows=junit(B/'WINDOWS_FINAL.xml'),linux=matrix,runner=dict(completed=18,resumed_without_duplication=True,bytes=sum(p.stat().st_size for p in (B/'utility-release').iterdir() if p.is_file())),sources=preservation)
(B/'FINAL_VERIFICATION.json').write_text(json.dumps(result,indent=2));print(json.dumps(dict(candidate=manifest['candidate_id'],windows=result['windows'],linux={v:r['full'] for v,r in matrix.items()},model_calls_succeeded=3)))
