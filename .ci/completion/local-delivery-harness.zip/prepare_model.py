import pathlib,shutil,subprocess
B=pathlib.Path(__file__).parent;M=B/'model';M.mkdir(exist_ok=True);R=pathlib.Path('C:/CAIN/work/supply-completion-20260912');PY=B/'venv/Scripts/python.exe'
if not (M/'research.db').exists():subprocess.run([str(PY),'-m','cain','research','restore',str(R/'backup.db'),str(M/'research.db')],check=True)
for name in ('policy.json','crypto-query.json','stocks-query.json','brasileirao-query.json'):
 shutil.copyfile(R/name,M/name)
script=(R/'real_model.py').read_text(encoding='utf-8').replace('C:/CAIN/work/supply-preview-20260912/venv/Scripts/python.exe',str(PY).replace('\\','/'))
(M/'real_model.py').write_text(script,encoding='utf-8')
