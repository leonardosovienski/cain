import pathlib,json,shutil,zipfile,hashlib
B=pathlib.Path(__file__).parent;kit=B/'ci-kit';source=pathlib.Path('C:/CAIN/work/supply-publish-20260912/.ci/completion')
if not kit.exists():shutil.copytree(source,kit)
manifest=json.loads((kit/'CANDIDATE_MANIFEST.json').read_bytes());local=json.loads((B/'CANDIDATE_MANIFEST.json').read_bytes());body=local['identity_payload']
for repo in manifest['repositories']:
 name=repo['repository'];overlay=kit/(name+'-overlay.zip')
 if name=='cain':
  shutil.copyfile(B/'overlay.zip',overlay)
  repo.update(file_hashes=body['changed_files'],overlay_files=body['overlay_files'])
 if name=='stocks':
  path=pathlib.Path('C:/STOCKS/work/supply-portability-20260912/tools/test_cain_bundle_selection.py');relative='tools/test_cain_bundle_selection.py'
  with zipfile.ZipFile(overlay,'w',zipfile.ZIP_DEFLATED) as z:z.write(path,relative)
  repo.update(file_hashes={relative:hashlib.sha256(path.read_bytes()).hexdigest()},overlay_files={relative:hashlib.sha256(path.read_bytes()).hexdigest()})
 repo['capture']['overlay_sha256']=hashlib.sha256(overlay.read_bytes()).hexdigest()
identity=[{k:r[k] for k in ('repository','base_head','branch','file_hashes','package_metadata')} for r in manifest['repositories']]
manifest.update(candidate_id=hashlib.sha256(json.dumps(identity,sort_keys=True,separators=(',',':')).encode()).hexdigest(),preview_candidate=local['candidate_id'])
(kit/'CANDIDATE_MANIFEST.json').write_text(json.dumps(manifest,indent=2))
shutil.copyfile(B/'runner.py',kit/'finite_runner.py')
shutil.copyfile(B/'CANDIDATE_MANIFEST.json',kit/'PREVIEW_MANIFEST.json')
shutil.copyfile('C:/CAIN/work/supply-publish-20260912/.github/workflows/cain-completion.yml',B/'cain-completion.yml')
print(json.dumps(dict(local=local['candidate_id'],transport=manifest['candidate_id'])))
