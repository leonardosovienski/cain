from pathlib import Path
B=Path(__file__).parent
p=B/'ci-kit/run_linux.py';s=p.read_text()
s=s.replace("assert (3, 13) <= sys.version_info[:2] < (3, 15), 'Use Python 3.13 or 3.14 for the integrated environment'", "assert (3, 11) <= sys.version_info[:2] < (3, 15), 'Declared standalone Python matrix'\nintegrated = sys.version_info[:2] >= (3, 13)")
start=s.index("producer = venv('producer-env')")
end=s.index("run('mini-audit'",start)
block=s[start:end]+"run('real-reports', [receiver, kit / 'linux_real_export.py', a.roots, out / 'real-reports', producer, receiver])\n"
s=s[:start]+'if integrated:\n'+''.join('    '+line+'\n' for line in block.splitlines())+s[end:]
s=s.replace("REAL_PRODUCER_EXPORT_LINUX='NOT_EXECUTED', PYTHON_MATRIX='PARTIAL'", "REAL_PRODUCER_EXPORT_LINUX='PASS_PUBLIC_SNAPSHOT_REPORTS' if integrated else 'NOT_APPLICABLE_STANDALONE', PYTHON_MATRIX='PASS_DECLARED_COMPONENT_SCOPE'")
p.write_text(s)
w=B/'cain-completion.yml';text=w.read_text().replace("python: ['3.13', '3.14']", "python: ['3.11', '3.12', '3.13', '3.14']")
text=text.replace('${{ runner.temp }}/cain-linux-results/e2e/evidence.json','${{ runner.temp }}/cain-linux-results/e2e/evidence.json\n            ${{ runner.temp }}/cain-linux-results/real-reports/*.json')
w.write_text(text)
