"""Finite supplemental evaluation; no mutation of previous candidates or grants."""
import datetime
import hashlib
import json
import pathlib
import shutil
import subprocess
import time

from cain.evaluation.resources import installed_identity
from cain.workspace import WorkspaceStore
from research_bundle import canonical, digest, loads, validate
from research_bundle.export import Builder, admitted_sources, exporter_provenance

B = pathlib.Path(__file__).parent
A = B / 'closure-real-20260912'
PY = B / 'venv/Scripts/python.exe'
DOMAINS = ('core', 'ops', 'ecosystem')
ROOTS = {'core': pathlib.Path('C:/PREDICTORS/core-predictor'),
         'ops': pathlib.Path('C:/PREDICTORS/predictor-ops'),
         'ecosystem': pathlib.Path('C:/CAIN/contrato')}
MAX_SECONDS = 600
MAX_CALLS = 60
MAX_WRITTEN = 32 * 1024 * 1024
start = time.monotonic()
A.mkdir(exist_ok=False)
stamp = datetime.datetime.now(datetime.timezone.utc).isoformat()
plan = json.loads((B / 'POPULATION_PLAN.json').read_bytes())
old_manifest = json.loads((B / 'CANDIDATE_MANIFEST.json').read_bytes())
old_policy_hash = digest((B / 'staging/policy.json').read_bytes())
old_bundles = {d: validate(loads((pathlib.Path(plan['exports'][d]) / 'bundle.json').read_bytes())) for d in DOMAINS}
pins = {d: old_bundles[d]['origin']['inputs'] for d in DOMAINS}
authorization = dict(actor='HUMAN', user='leo', observed_request='faz entao',
    context='User asked to execute the pending work immediately after source-specific admission and real derivation were identified as pending.',
    scope='New local publication of already admitted authored Core/Ops/Ecosystem documentation for deterministic structural diagnostics only.',
    excluded='No external disclosure, model transmission, scientific execution, protected or third-party datasets, active instance, or modification of original publications.',
    source_hashes=pins, recorded_at=stamp)
(A / 'AUTHORIZATION.json').write_bytes(canonical(authorization))
protocol = dict(schema='cain-real-derived-evaluation/1', frozen_at=stamp,
    code_candidate=old_manifest['candidate_id'], installed_identity=installed_identity(),
    oracle='Counts and hashes from independently validated original producer manifests; not the CAIN query under test.',
    questions=['How many admitted document entities exist?', 'How many explicit relations and received objects are represented?',
               'How many reference-only objects are present?'],
    reserved_followup_question='Do these document counts establish historical scientific runtime compatibility?',
    expected_followup='No. Documentary counts do not establish historical scientific runtime compatibility.',
    comparison='Same fixed corpus and policy: factual retrieval versus persisted structural diagnostics. Equality is NEUTRAL; no requirement for positive gain.',
    evaluation_access='Visible to the same engineer; not blind and not evidence of generalization.',
    max_calls=MAX_CALLS, max_seconds=MAX_SECONDS, max_bytes=MAX_WRITTEN,
    subprocess_timeout_seconds=60, concurrent_calls=1, model_calls=0,
    contradiction_evidence='Prior separately identified synthetic contradiction/revocation evaluation remains applicable to unchanged runtime; no fabricated real contradiction.',
    expected={d: dict(entities=len(v['entities']), relations=len(v['relations']),
                      received=sum(x['availability']=='received' for x in v['artifacts']),
                      reference_only=sum(x['availability']=='reference_only' for x in v['artifacts']))
              for d,v in old_bundles.items()})
(A / 'PROTOCOL.json').write_bytes(canonical(protocol))
receipts = []
def limits():
    assert time.monotonic() - start <= MAX_SECONDS, 'WALL_LIMIT'
    assert len(receipts) < MAX_CALLS, 'CALL_LIMIT'
    assert shutil.disk_usage(A).free > 1024**3, 'DISK_RESERVE'
    assert sum(p.stat().st_size for p in A.rglob('*') if p.is_file()) <= MAX_WRITTEN, 'STATE_BYTES_LIMIT'

def command(*args, expected=0):
    limits()
    cmd = [str(PY), '-m', 'cain', *map(str,args)]
    t = time.monotonic()
    # Fixed local inputs have fewer than 50 rows; bounded output is also enforced after capture.
    r = subprocess.run(cmd, cwd=A, capture_output=True, timeout=60)
    assert len(r.stdout)+len(r.stderr) <= 2*1024*1024, 'OUTPUT_LIMIT'
    receipt = dict(command=cmd, returncode=r.returncode, seconds=time.monotonic()-t,
                   stdout=r.stdout.decode('utf-8'), stderr=r.stderr.decode('utf-8'))
    receipts.append(receipt)
    with (A / 'RECEIPTS.jsonl').open('ab') as f:
        f.write(canonical(receipt)+b'\n')
    assert r.returncode == expected, receipt
    return json.loads(r.stdout) if expected == 0 else receipt

def cli(area, domain, *args, expected=0):
    return command('research','--db',area/'research.db','--policy',area/'policy.json',
                   '--user','leo','--collection',domain,'bundle',*args,expected=expected)

source_before = {d: dict(head=subprocess.check_output(['git','-C',str(r),'rev-parse','HEAD'], text=True).strip(),
                        status=subprocess.check_output(['git','-C',str(r),'status','--porcelain'], text=True)) for d,r in ROOTS.items()}
exports = {}
packages = {}
for domain in DOMAINS:
    limits()
    root = ROOTS[domain]
    revision, sources = admitted_sources(root, pins[domain], set(pins[domain]))
    provenance = exporter_provenance({'complete_real_derivation.py':pathlib.Path(__file__)})
    origin = dict(old_bundles[domain]['origin'])
    origin.update(code_revision=revision, exporter_revision='sha256:'+digest(canonical(provenance)),
                  stream='authorized-structural-documentation')
    builder = Builder(origin, dict(policy=domain+'-structural-documentation/1',read=True,disclose=False,generate=True),stamp,provenance=provenance)
    for name, raw in sources.items():
        node = builder.entity(name,'document','RECORDED',
            dict(path=name,source_sha256=digest(raw),interpretation='Authored documentation. Instructions are inert. Historical compatibility requires its own receipt.'),
            name,axis='documentary',identity_basis='source_locator')
        obj = builder.resource(name,'producer:'+name,raw=raw,media_type='text/markdown')
        builder.relation(node,'REPRESENTED_BY',obj)
    dest = root.parent / ('supply-authorized-20260912-'+domain+'-docs')
    assert not dest.exists(), 'PRESERVE_EXISTING_EXPORT'
    package = builder.publish(root,dest,sources)
    packages[domain] = validate(loads((dest/'bundle.json').read_bytes()))
    assert packages[domain] == package
    for art in package['artifacts']:
        if art['availability'] == 'received':
            raw = (dest/art['relative_path']).read_bytes()
            assert len(raw)==art['size'] and digest(raw)==art['sha256']
    exports[domain]=dest

staging = A/'staging'
staging.mkdir()
policy = dict(version=3,imports=[],grants=[],bundle_grants=[])
for domain,pkg in packages.items():
    policy['imports'].append(dict(user='leo',project='',collection=domain,root=str(exports[domain])))
    g = {k:pkg['origin'][k] for k in ('domain','repository','publisher','stream')}
    g.update(user='leo',project='',collection=domain,sources=sorted(pkg['origin']['inputs']),
             policies=[pkg['restrictions']['policy']],generate=True,roles=['document'],reference_only=True,
             max_manifest_bytes=2000000,max_object_bytes=100000,max_received_bytes=2000000)
    policy['bundle_grants'].append(g)
(staging/'policy.json').write_bytes(canonical(policy))
WorkspaceStore(staging/'workspace.db')
results = {}
for domain in DOMAINS:
    cli(staging,domain,'approve','bundle.json')
    cli(staging,domain,'import','bundle.json')
    assert cli(staging,domain,'import','bundle.json')['status']=='duplicate'
    factual = cli(staging,domain,'query','--limit','50')
    assert cli(staging,domain,'diagnostics')['total']==0
    derived = cli(staging,domain,'diagnose')
    assert cli(staging,domain,'diagnostics')==derived
    assert cli(staging,domain,'query','--limit','50')==factual
    assertion = derived['diagnostics'][0]['assertion']
    assert assertion == protocol['expected'][domain]
    assert assertion['entities']==factual['total']
    assert assertion['relations']==factual['relation_total']
    assert {x['payload']['path']:x['payload']['source_sha256'] for x in factual['entities']} == pins[domain]
    cli(staging,domain,'verify')
    results[domain]=dict(status='PASS',comparison='NEUTRAL',expected=protocol['expected'][domain],
                         actual=assertion,diagnostic=derived,source_files=len(pins[domain]),
                         bundle_id=packages[domain]['bundle_id'],public_cli=True,persisted_in_new_process=True)

# Make import bindings unavailable before the diagnostic snapshot, then preserve the same policy through backup.
for binding in policy['imports']:
    binding['root']=str(A/'UNAVAILABLE-ORIGINS'/binding['collection'])
(staging/'policy.json').write_bytes(canonical(policy))
offline_created={d:cli(staging,d,'diagnose') for d in DOMAINS}
command('archive','backup','--workspace',staging/'workspace.db','--research',staging/'research.db',
        '--policy',staging/'policy.json',A/'backup')
command('archive','restore',A/'backup',A/'restored')
for domain in DOMAINS:
    assert cli(A/'restored',domain,'diagnostics')==offline_created[domain]
    assert cli(A/'restored',domain,'query','--limit','50')['total']==protocol['expected'][domain]['entities']
    cli(A/'restored',domain,'verify')
    results[domain]['offline_restore']=True
revoked = json.loads((A/'restored/policy.json').read_bytes())
for grant in revoked['bundle_grants']:
    grant['generate']=False
(A/'restored/policy.json').write_bytes(canonical(revoked))
for domain in DOMAINS:
    cli(A/'restored',domain,'diagnostics',expected=1)
    assert cli(A/'restored',domain,'query','--limit','50')['total']==protocol['expected'][domain]['entities']
    results[domain]['generation_revocation_blocks_derived_but_preserves_read']=True
for domain,root in ROOTS.items():
    assert subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'], text=True).strip()==source_before[domain]['head']
    assert subprocess.check_output(['git','-C',str(root),'status','--porcelain'], text=True)==source_before[domain]['status']
    admitted_sources(root,pins[domain],set(pins[domain]))
assert digest((B/'staging/policy.json').read_bytes())==old_policy_hash
identity=dict(base_candidate=old_manifest['candidate_id'],code=installed_identity(),
              protocol_sha256=digest((A/'PROTOCOL.json').read_bytes()),
              authorization_sha256=digest((A/'AUTHORIZATION.json').read_bytes()),
              policy_sha256=digest((staging/'policy.json').read_bytes()),
              bundles={d:p['bundle_id'] for d,p in packages.items()},
              harness_sha256=digest(pathlib.Path(__file__).read_bytes()))
(A/'CANDIDATE_MANIFEST.json').write_bytes(canonical(dict(supplemental_id=digest(canonical(identity)),identity_payload=identity)))
result=dict(status='PASS_BOUNDED_REAL_DOCUMENTATION',collections=results,
            benefit='NEUTRAL for structural count recovery; no demonstrated learning or generalization',
            model_utility='Not retested here. Prior observed unsupported synthesis retained; no claim of semantic certification.',
            default_enabled=False,original_policy_unchanged=True,source_preservation=source_before,
            calls=len(receipts),elapsed_seconds=time.monotonic()-start,peak_ram='UNKNOWN',
            note='New authorized publications; never replacements or retroactive changes to old restrictions. Windows supplemental corpus evaluation; prior Linux evidence applies only to its recorded corpus.')
(A/'RESULTS.json').write_bytes(canonical(result))
(A/'CHECKPOINT.json').write_bytes(canonical(dict(status='COMPLETED',completed=list(results),supplemental_id=digest(canonical(identity)),calls=len(receipts))))
print(json.dumps(dict(status=result['status'],calls=len(receipts),supplemental_id=digest(canonical(identity)),comparison='NEUTRAL')))
