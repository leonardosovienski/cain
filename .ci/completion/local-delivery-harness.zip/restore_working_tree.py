"""Restore exact candidate into a NEW local checkout; never resets an existing tree."""
import argparse,hashlib,json,pathlib,subprocess,zipfile
B=pathlib.Path(__file__).parent
p=argparse.ArgumentParser();p.add_argument('--destination',type=pathlib.Path,required=True);a=p.parse_args()
dest=a.destination.resolve()
if dest.exists() or not dest.is_relative_to(pathlib.Path('C:/CAIN/work').resolve()):raise ValueError('Use a new directory inside C:/CAIN/work')
m=json.loads((B/'CANDIDATE_MANIFEST.json').read_bytes());body=m['identity_payload']
assert hashlib.sha256(json.dumps(body,sort_keys=True,separators=(',',':')).encode()).hexdigest()==m['candidate_id']
assert hashlib.sha256((B/'overlay.zip').read_bytes()).hexdigest()==body['overlay_sha256']
repo=next(r for r in body['base_repositories'] if r['repository']=='cain')
subprocess.run(['git','clone','--no-hardlinks','--no-checkout',repo['root'],str(dest)],check=True)
subprocess.run(['git','-C',str(dest),'checkout','--detach',repo['head']],check=True)
with zipfile.ZipFile(B/'overlay.zip') as z:
 assert set(z.namelist())==set(body['overlay_files'])
 for name,h in body['overlay_files'].items():
  path=dest/name
  if not path.resolve().is_relative_to(dest):raise ValueError('Unsafe path')
  raw=z.read(name);assert len(raw)<=2000000 and hashlib.sha256(raw).hexdigest()==h
  path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)
print(json.dumps(dict(status='RESTORED_EXACT_OVERLAY',candidate_id=m['candidate_id'],destination=str(dest))))
