"""One-shot manual adapter to the installed public CAIN CLI, with a local receipt."""
import argparse, datetime, json, pathlib, subprocess, sys
B=pathlib.Path(__file__).parent
p=argparse.ArgumentParser(description='CAIN staging factual CLI; each invocation exits automatically.')
p.add_argument('--collection',choices=('crypto','brasileirao','stocks','core','ops','ecosystem'),required=True)
p.add_argument('action',choices=('query','lineage','artifacts','evidence','entity','artifact','historian','verify','receipts','diagnose','diagnostics'))
p.add_argument('options',nargs=argparse.REMAINDER)
a=p.parse_args()
cmd=[sys.executable,'-m','cain','research','--db',str(B/'staging/research.db'),'--policy',str(B/'staging/policy.json'),'--user','leo','--collection',a.collection,'bundle',a.action,*a.options]
r=subprocess.run(cmd,cwd=B,capture_output=True,timeout=60)
record=dict(at=datetime.datetime.now(datetime.timezone.utc).isoformat(),command=cmd,stdout=r.stdout.decode('utf-8',errors='replace'),stderr=r.stderr.decode('utf-8',errors='replace'),returncode=r.returncode)
with (B/'USER_OBSERVATIONS.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(record,ensure_ascii=False)+'\n')
sys.stdout.buffer.write(r.stdout);sys.stderr.buffer.write(r.stderr);sys.exit(r.returncode)
