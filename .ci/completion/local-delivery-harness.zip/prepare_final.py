import json,pathlib,shutil,subprocess,hashlib,zipfile
from cain.evaluation.resources import installed_identity
B=pathlib.Path(__file__).parent; P=pathlib.Path('C:/CAIN/work/supply-preview-20260912'); C=B/'candidate'
PY=B/'venv/Scripts/python.exe'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
for name in ('preview.py','POPULATION_PLAN.json','BASELINE.json'):
 if not (B/name).exists():shutil.copyfile(P/name,B/name)
if not (B/'staging').exists():
 subprocess.run([str(PY),'-m','cain','archive','restore',str(P/'backup'),str(B/'staging')],check=True)
config=json.loads((P/'UTILITY_PROTOCOL.json').read_bytes())
config.update(db=str(B/'staging/research.db'),policy=str(B/'staging/policy.json'),expected_code=installed_identity()['source_tree_sha256'],expected_policy=sha((B/'staging/policy.json').read_bytes()))
(B/'UTILITY_PROTOCOL.json').write_text(json.dumps(config,indent=2))
old=json.loads((P/'CANDIDATE_MANIFEST.json').read_bytes())
body=dict(old['identity_payload'])
def git(*args):return subprocess.check_output(['git','-C',str(C),*args])
changed=set(filter(None,(git('diff','--name-only','-z','HEAD')+git('ls-files','--others','--exclude-standard','-z')).decode().split('\0')))
files={f:sha((C/f).read_bytes()) for f in sorted(changed)}
overlay=dict(files)
for f in body['overlay_files']:overlay[f]=sha((C/f).read_bytes())
with zipfile.ZipFile(B/'overlay.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(overlay):
  info=zipfile.ZipInfo(f,date_time=(2026,9,12,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
  z.writestr(info,(C/f).read_bytes())
(B/'candidate.patch').write_bytes(git('diff','--binary','HEAD'))
installed=installed_identity();wheel=B/'wheels/cain_research-0.4.7-py3-none-any.whl'
with zipfile.ZipFile(wheel) as z:
 packaged={n[5:]:sha(z.read(n)) for n in z.namelist() if n.startswith('cain/') and pathlib.Path(n).suffix in {'.py','.json','.md','.html','.css','.js'}}
assert packaged==installed['source_sha256']
assert all(sha((C/'src/cain'/n).read_bytes())==h for n,h in packaged.items())
stock=pathlib.Path('C:/STOCKS/work/supply-portability-20260912/tools/test_cain_bundle_selection.py')
body.update(candidate_root=str(C),changed_files=files,overlay_files=overlay,overlay_sha256=sha((B/'overlay.zip').read_bytes()),patch_sha256=sha((B/'candidate.patch').read_bytes()),wheel_sha256=sha(wheel.read_bytes()),installed_code_identity=installed['source_tree_sha256'],dependency_identity=installed['dependency_identity'],runner_sha256=sha((B/'runner.py').read_bytes()),protocol_sha256=sha((B/'UTILITY_PROTOCOL.json').read_bytes()),predecessor_candidate=old['candidate_id'],stocks_test_overlay={str(stock):sha(stock.read_bytes())})
manifest=dict(candidate_id=sha(json.dumps(body,sort_keys=True,separators=(',',':')).encode()),identity_payload=body,identity_algorithm=old['identity_algorithm'])
(B/'CANDIDATE_MANIFEST.json').write_text(json.dumps(manifest,indent=2))
shutil.copyfile(P/'restore_working_tree.py',B/'restore_working_tree.py')
print(manifest['candidate_id'])
