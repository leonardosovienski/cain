import json
import pathlib
import subprocess

B = pathlib.Path(__file__).parent
P = pathlib.Path('C:/CAIN/work/supply-publish-20260912')
def git(*args):
    return subprocess.check_output(['git', '-C', str(P), *args], text=True).strip()
r = json.loads((B / 'REMOTE_FINAL_VERIFICATION.json').read_bytes())
tested = 'f0cfb92b20a41e615d28f41e93bae589d680cf84'
head = git('rev-parse', 'HEAD')
remote = git('ls-remote', 'origin', 'refs/heads/' + r['branch']).split()[0]
assert head == remote
assert git('status', '--porcelain') == ''
assert git('diff', '--name-only', tested, head) == '.ci/completion/README.md'
assert (P / '.ci/completion/README.md').read_bytes() == (B / 'ci-kit/README.md').read_bytes()
r.update(validated_runtime_head=tested, publication_head=head, publication_remote_head=remote,
         documentation_only_changes=['.ci/completion/README.md'],
         documentation_ci='Skipped for README-only update; run_id remains attached to validated_runtime_head')
(B / 'REMOTE_FINAL_VERIFICATION.json').write_text(json.dumps(r, indent=2), encoding='utf-8')
p = B / 'final_reports.py'
s = p.read_text(encoding='utf-8')
s = s.replace("HEAD local e remoto **`{remote['head']}`**. CI exata:", "HEAD de publicação local e remoto **`{remote['publication_head']}`**. O último commit altera somente o README, com CI dispensado. Runtime validado no commit **`{remote['validated_runtime_head']}`**, sem alteração posterior de código ou manifesto. CI exata desse runtime:")
s = s.replace("candidate=cid,remote=remote['head'],gates=gates", "candidate=cid,remote=remote['publication_head'],validated_runtime_head=remote['validated_runtime_head'],gates=gates")
replacements = {
    'usou559 de4096':'usou 559 de 4096', 'de90s':'de 90 s', 'de180s':'de 180 s',
    'CAIN0.4.7':'CAIN 0.4.7', 'Python3.12':'Python 3.12', 'Python3.11':'Python 3.11',
    'binding127':'binding 127', 'tem70':'tem 70', 'entidades,47':'entidades, 47',
    'e6 referências,231658':'e 6 referências, 231658', 'contém15':'contém 15',
    'Houve3':'Houve 3', 'e1 timeout':'e 1 timeout', 'após2':'após 2', 'até18':'até 18',
    'Limites:24':'Limites: 24', ',600s,45s/subprocesso,concorrência1,zero modelos,2MB por captura,32MB':' , 600 s, 45 s/subprocesso, concorrência 1, zero modelos, 2 MB por captura, 32 MB',
    'reserva1GiB':'reserva 1 GiB', 'Portas8889':'Portas 8889', 'scopes;12':'scopes; 12',
    'e18 casos':'e 18 casos', 'Crypto15':'Crypto 15', 'Stocks1':'Stocks 1', 'BR3':'BR 3',
    'é89':'é 89', 'Modelo:3':'Modelo: 3', ',1 timeout':', 1 timeout',
    'aprovados,1':'aprovados, 1', 'e2 skips':'e 2 skips', 'produtores3.13':'produtores 3.13',
    'Crypto23,BR11,Stocks15':'Crypto 23, BR 11, Stocks 15',
    'Crypto20':'Crypto 20', 'BR14':'BR 14', 'Stocks2':'Stocks 2',
    'isso2':'isso 2', 'versus3':'versus 3', 'preserva70':'preserva 70',
    'recebidos,6 references e231658':'recebidos, 6 referências e 231658',
    'Core16,Ops11,Ecosystem6':'Core 16, Ops 11, Ecosystem 6',
    'acrescenta9':'acrescenta 9', 'e19 revisões':'e 19 revisões', 'os18 resultados':'os 18 resultados'
}
for old, new in replacements.items():
    s = s.replace(old, new)
p.write_text(s, encoding='utf-8')
print(json.dumps({'status':'PASS', 'publication_head':head, 'tested_runtime_head':tested}))
