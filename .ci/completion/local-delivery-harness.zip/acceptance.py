import json,pathlib,subprocess,hashlib,os,time
from cain.workspace import WorkspaceStore
B=pathlib.Path(__file__).parent; PY=B/'venv/Scripts/python.exe'
plan=json.loads((B/'POPULATION_PLAN.json').read_bytes())
receipts=[]
def run(args,expect=0):
 cmd=[str(PY),*map(str,args)];r=subprocess.run(cmd,cwd=B,capture_output=True,timeout=60)
 item=dict(command=cmd,returncode=r.returncode,stdout=r.stdout.decode('utf-8',errors='replace'),stderr=r.stderr.decode('utf-8',errors='replace'))
 receipts.append(item)
 with (B/'ACCEPTANCE_LEDGER.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(item,ensure_ascii=False)+'\n')
 assert r.returncode==expect,item
 return json.loads(r.stdout) if r.returncode==0 else item
def research(root,domain,*args,expect=0):
 return run(['-m','cain','research','--db',root/'research.db','--policy',root/'policy.json','--user','leo','--collection',domain,'bundle',*args],expect)
WorkspaceStore(B/'staging/workspace.db')
run(['-m','cain','archive','backup','--workspace',B/'staging/workspace.db','--research',B/'staging/research.db','--policy',B/'staging/policy.json',B/'backup'])
run(['-m','cain','archive','restore',B/'backup',B/'restored'])
# No producer root is renamed or modified. Make only the disposable restored bindings unavailable.
p=B/'restored/policy.json';policy=json.loads(p.read_bytes())
for binding in policy['imports']:binding['root']=str(B/'UNAVAILABLE-PRODUCER-BINDING'/binding['collection'])
p.write_text(json.dumps(policy),encoding='utf-8')
results={}
for domain,root in plan['exports'].items():
 pkg=json.loads((pathlib.Path(root)/'bundle.json').read_bytes())
 first=run([B/'preview.py','--collection',domain,'query','--limit','50'])
 again=run([B/'preview.py','--collection',domain,'query','--limit','50']);assert first==again
 restored=research(B/'restored',domain,'query','--limit','50');assert restored==first
 run([B/'preview.py','--collection',domain,'lineage','--limit','50'])
 run([B/'preview.py','--collection',domain,'artifacts','--limit','50'])
 ev=pkg['evidence'][0]
 got=run([B/'preview.py','--collection',domain,'evidence',pkg['bundle_id'],ev['id']]);assert got['evidence']['payload']==ev['payload']
 assert {e['entity_id']:e['payload'] for e in first['entities']}=={e['entity_id']:e['payload'] for e in pkg['entities']}
 research(B/'restored',domain,'verify');research(B/'restored',domain,'rebuild')
 count=0
 for a in pkg['artifacts']:
  if a['availability']=='received':
   target=B/'materialized'/(domain+'-'+a['sha256']);target.parent.mkdir(exist_ok=True)
   research(B/'restored',domain,'materialize',pkg['bundle_id'],a['artifact_id'],target)
   assert hashlib.sha256(target.read_bytes()).hexdigest()==a['sha256'];count+=1
 run([B/'preview.py','--collection',domain,'diagnose'],expect=1)
 results[domain]=dict(restart='PASS',public_cli='PASS',source_evidence='PASS',relations='PASS',received_and_reference='PASS',offline_restore='PASS',materialized=count,temporal_payload_fidelity='PASS_EXACT_SOURCE_FIELDS',generation='AUTHORIZATION_EXPECTED')
# Revocation and projection corruption are confined to restored disposable state.
policy['bundle_grants']=[g for g in policy['bundle_grants'] if g['collection']!='crypto'];p.write_text(json.dumps(policy))
q=research(B/'restored','crypto','query');assert q['total']==0 and q['artifact_total']==0 and q['relation_total']==0
research(B/'restored','crypto','diagnostics',expect=1)
(B/'ACCEPTANCE_RESULTS.json').write_text(json.dumps(dict(status='PASS_BOUNDED_CLI',collections=results,revocation='PASS',web_interactive='NOT_EXECUTED',real_model='NOT_EXECUTED_GENERATION_NOT_ADMITTED',restored_policy='Only removed permissions and replaced import bindings in disposable restored copy'),indent=2))
print(json.dumps(results,indent=2))
