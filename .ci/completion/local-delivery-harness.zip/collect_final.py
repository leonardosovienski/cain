import json,pathlib,hashlib,subprocess,xml.etree.ElementTree as ET,socket
B=pathlib.Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
artifacts=json.loads((B/'REMOTE_FINAL_ARTIFACTS.json').read_text(encoding='utf-8-sig'))['artifacts']
matrix={}
for item in artifacts:
 v=item['name'].split('-')[-1];area=B/('linux-final-'+v)
 assert sha(B/('linux-final-'+v+'.zip'))==item['digest'].split(':')[1]
 results={}
 for name in ('full','targeted','mini-audit'):
  tree=ET.parse(area/(name+'.xml'));suites=list(tree.iter('testsuite'))
  counts={k:sum(int(s.get(k,0)) for s in suites) for k in ('tests','failures','errors','skipped')}
  assert counts['failures']==counts['errors']==0
  skipped=[dict(name=t.get('name'),reason=t.find('skipped').get('message')) for t in tree.iter('testcase') if t.find('skipped') is not None]
  if name!='full':assert not skipped
  else:assert {s['name'] for s in skipped}=={'test_api_launcher_does_not_prepare_ollama','test_windows_launcher_refuses_other_service_without_stopping_it'}
  results[name]=dict(counts=counts,skips=skipped)
 results['source_equivalence']=json.loads((area/'source-equivalence.json').read_bytes())
 if v in ('3.13','3.14'):
  results['real_snapshots']=json.loads((area/'real-reports/evidence.json').read_bytes())
  results['real_bundles']=json.loads((area/'real-reports/bundle-evidence.json').read_bytes())
  assert results['real_bundles']['status']==results['real_snapshots']['status']=='PASS'
 matrix[v]=results
root='C:/CAIN/work/supply-publish-20260912';branch='validation/cain-supply-completion-20260912'
head=subprocess.check_output(['git','-C',root,'rev-parse','HEAD']).decode().strip()
remote=subprocess.check_output(['git','-C',root,'ls-remote','origin','refs/heads/'+branch]).decode().split()[0]
assert head==remote=='f0cfb92b20a41e615d28f41e93bae589d680cf84'
ports={}
for p in (8889,11439):
 with socket.socket() as s:s.bind(('127.0.0.1',p));ports[str(p)]='released'
result=dict(status='PASS',head=head,remote_head=remote,branch=branch,run_id=34702803998,baseline_ci_run_id=34702803984,matrix=matrix,owned_ports=ports)
(B/'REMOTE_FINAL_VERIFICATION.json').write_text(json.dumps(result,indent=2))
print(json.dumps(dict(remote=head,matrix=list(matrix),real_bundle_exports='PASS',ports=ports)))
