import json,pathlib,shutil,hashlib,collections
B=pathlib.Path(__file__).parent;P=pathlib.Path('C:/CAIN/work/supply-preview-20260912');R=pathlib.Path('C:/CAIN/work/supply-completion-20260912')
O=pathlib.Path('C:/Users/leona/Documents/Codex/2026-09-12/lei/outputs');O.mkdir(exist_ok=True)
m=json.loads((B/'CANDIDATE_MANIFEST.json').read_bytes());cid=m['candidate_id'];body=m['identity_payload']
remote=json.loads((B/'REMOTE_FINAL_VERIFICATION.json').read_bytes());v=json.loads((B/'FINAL_VERIFICATION.json').read_bytes());model=json.loads((B/'MODEL_VERIFICATION.json').read_bytes());coverage=json.loads((P/'KNOWLEDGE_COVERAGE.json').read_bytes())
assert remote['status']=='PASS' and json.loads((B/'ACCEPTANCE_RESULTS.json').read_bytes())['status']=='PASS_BOUNDED_CLI'
for name in ('SESSION_BASELINE.md','SOURCE_INVENTORY.json','POPULATION_LEDGER.jsonl','KNOWLEDGE_COVERAGE.json'):
 if (P/name).exists():shutil.copyfile(P/name,B/name)
shutil.copyfile(R/'INVENTORY.json',B/'LEGACY_SOURCE_INVENTORY.json')
for name in ('INDEPENDENT_REVIEW.md','RE_REVIEW_FINAL.md','DELIVERY_REVIEW.md'):
 shutil.copyfile(pathlib.Path('C:/CAIN/work/supply-review-20260912')/name,B/name)
results=[]
checkpoint=json.loads((B/'utility-release/CHECKPOINT.json').read_bytes())
for item in checkpoint['completed'].values():results.append(json.loads((B/'utility-release'/item['result']).read_bytes()))
(B/'UTILITY_RESULTS.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in results),encoding='utf-8')
derived=json.loads((B/'derived-evaluation-r2/RESULTS.json').read_bytes())
(B/'DERIVED_VALIDATION.jsonl').write_text(json.dumps(derived)+'\n')
requests=[]
for domain in ('crypto','brasileirao','stocks','core','ops','ecosystem'):
 requests.append(dict(collection=domain,source_identity=body['corpus_bundles'][domain],
  requested_operation='Consider deterministic structural derivation over this already received bundle metadata',
  destination=str(B/'staging'),current_status='Producer restrictions and receiver grants generate=false',
  required_decision='Explicit producer/receiver administrative decision; new publication or grant revision where appropriate',
  notes='The conservative false setting on newly exported documentation is not proof of a universal licensing prohibition. No permission changed to pass tests.'))
(B/'ADMISSION_REQUESTS.json').write_text(json.dumps(dict(requests=requests,additional_sources='Other tracked files remain discovered metadata only; inspect source-specific permission before any new receipt. Stocks prices/raw backup, protected cohorts, and unknown runtime receipts are not newly admitted.'),indent=2))
gates={
 'CANDIDATE_IDENTITY_STATUS':'PASS','LEGACY_COMPATIBILITY_STATUS':'PASS','CONTRACT_AND_PROFILE_STATUS':'PASS',
 'WINDOWS_STATUS':'PASS','LINUX_STATUS':'PASS','PYTHON_MATRIX_STATUS':'PASS',
 'F01_F10_STATUS_BY_PLATFORM':{'Windows':'PASS within executed regression cases; symlink privilege case not executed here',
  'Linux':'PASS within executed remediations and POSIX probes; required symlink executed; F09 documentation review is platform-neutral'},
 'INVENTORY_STATUS':'PARTIAL_JUSTIFIED','POPULATION_STATUS_BY_SOURCE_AND_CLASS':{d:'PARTIAL_JUSTIFIED' for d in coverage},
 'COVERAGE_STATUS':'PARTIAL_JUSTIFIED','DETERMINISTIC_QUERY_STATUS':'PASS','TEMPORAL_AND_LINEAGE_STATUS':'PASS',
 'MODEL_UTILITY_STATUS':'INCONCLUSIVE','DERIVED_PIPELINE_STATUS':'PASS','DERIVED_BENEFIT_STATUS':'INCONCLUSIVE',
 'SECURITY_AND_REVOCATION_STATUS':'PASS','BACKUP_RESTORE_OFFLINE_STATUS':'PASS','WHEEL_INSTALL_STATUS':'PASS',
 'REMOTE_CI_STATUS':'PASS','INDEPENDENT_REVIEW_STATUS':'PASS','SCIENTIFIC_INTEGRITY_STATUS':'PASS',
 'READY_FOR_FREEZE_REVIEW':'PASS','USER_PREVIEW_STATUS':'LIMITED_IN_STAGING'}
scope=dict(candidate=cid,gates=gates,meaning='Ready to review the bounded Supply engineering candidate, not administratively frozen, deployed or scientifically validated',
 matrix_scope='CAIN/Bundle/Snapshot standalone 3.11–3.14; producer integration/export tools 3.13–3.14. Not the full economic runtimes or every OS/version Cartesian combination.',
 derived_scope='New structural mechanism verified with synthetic authorized fixtures; all six real Bundle derivations denied by existing restrictions. No real learning benefit.',
 source_scope='70 Bundle entities and 19 legacy record revisions are different units; not 89 experiments. Inventory covers tracked paths plus explicitly admitted publications, not all disks/databases.',
 scientific_integrity_evidence='No scientific write command; original seven HEAD/status and selected hashes unchanged. No kernel-wide proof and no claim of zero protected reads during the earlier interrupted baseline scan.',
 model_scope='Three real successful local generations, one timeout retained, one longer-timeout retry. Exact quotations passed; synthesis not certified. Stocks synthesis adds an unsupported individual interpretation.',
 linux_scope='Real Bundle Crypto 20/BR 14/Stocks 2; Windows existing Stocks3 additionally contains an optional selection. No scientific backup uploaded to reproduce that optional real selection on Linux.')
(B/'GATES.json').write_text(json.dumps(scope,indent=2))
fmap={
 'F01':('Verification before protected object I/O','test_verify_denies_entire_scope_before_object_io'),
 'F02':('External relations do not bypass roles','test_external_is_not_role_permission'),
 'F03':('Administrative approval and atomic reservations','test_admin_reservation_precedes_membership'),
 'F04':('Descriptor revision disambiguation','test_descriptor_revision_disambiguates_and_unresolved_hidden'),
 'F05':('Raw variants preserved with quotas','test_raw_variants_backup_integrity'),
 'F06':('Evidence-only facts reachable and revocable','test_evidence_only_fact_retrievable_and_revoked'),
 'F07':('Directory durability failure blocks commit','test_directory_sync_failure_prevents_metadata_commit'),
 'F08':('No domain defaults in shared exporter','test_provenance_tracks_dependency_bytes_and_builder_has_no_domain_defaults'),
 'F09':('Current handoff distinguishes historical claims','FINAL_HANDOFF.md plus preserved BUNDLE_REMEDIATION.md'),
 'F10':('Executed dependency/code provenance','test_provenance_tracks_dependency_bytes_and_builder_has_no_domain_defaults plus DELIVERY_REVIEW.md')}
(B/'F01_F10_MATRIX.json').write_text(json.dumps({k:dict(problem=p,evidence=e,windows='PASS_EXECUTED_SCOPE',linux='PASS_EXECUTED_SCOPE' if k!='F09' else 'NOT_APPLICABLE_DOCUMENTATION',limit='Not universal vulnerability or physical power-loss proof') for k,(p,e) in fmap.items()},indent=2))
findings='''# Findings e remediação final

Relatórios e candidatos anteriores foram preservados. F01–F10: mapa em F01_F10_MATRIX.json, relatório original em C:/CAIN/work/bundle-audit-20260912/REPORT.md e remediação histórica em C:/CAIN/work/research-bundle-v1/docs/research/BUNDLE_REMEDIATION.md.

- Distribuição: os quatro recursos de avaliação foram empacotados sem regenerar seus bytes; instalação fora do checkout e comparação com os originais passaram.
- Revisão independente R1: payload adulterado de diagnóstico era retornado como válido. Agora há recomputação dos campos estruturais e checagem de identidade. Regressões de corrupção passaram.
- R2: paginação e persistência do diagnóstico não compartilhavam snapshot. Leitura usa uma transação; criação reserva escrita antes de ler. Probe WAL com ingestão concorrente retornou snapshot coerente, depois invalidou o diagnóstico anterior.
- R3: runner excedia quota ao serializar resultados. Agora limita captura em memória, considera resultado/checkpoint/temporários, e para com LIMIT_REACHED. Probe usou 559 de 4096 bytes. Uma regressão inicial de sobrescrita de checkpoint foi corrigida e re-revisada; configurações rejeitadas preservam o checkpoint e gravam LAST_LIMIT separado.
- Identidade passou a incluir bytes de Bundle/Snapshot. Ruff dividiu imports e formatou o runner; comparação AST independente não encontrou alteração funcional.
- Linux: fixture Stocks usava diretório fixo Windows. Mudou somente a fixture em overlay isolado C:/STOCKS/work/supply-portability-20260912. Runtime e fontes Stocks permaneceram intactos.
- Ensaio Linux Bundle inicialmente escolheu destino fora da área permitida do produtor. A proteção recusou; apenas o harness mudou para destinos irmãos dos checkouts. Repetição final passou.
- Modelo: timeout de 90 s em Brasileirão foi preservado. Uma tentativa serial de 180 s passou. Não houve fallback remoto nem mudança de modelo. Citações literais passaram, mas a síntese Stocks introduziu interpretação sobre indivíduo sem apoio; continua experimental e não é recomendação.
- Comparação derivada: a primeira fixture adversarial conflitava com uma identidade/revisão já aprovada. A recusa foi correta. Nova revisão explícita da fixture permitiu testar conteúdo hostil sem reescrever a identidade anterior. Resultado estrutural neutro; contradição, revogação e restore passaram. Os seis bundles reais continuaram negando geração.
- Verificador final inicialmente exigia zero skips de qualquer espécie no Linux. Foram identificados exatamente dois testes exclusivos de launcher Windows, ambos aprovados no Windows. O verificador passou a conferir essa correspondência; nenhum gate POSIX/symlink obrigatório foi removido.

Limitações de observabilidade: RAM de pico não medida; quota de armazenamento do harness não é quota de kernel. A preservação científica combina comandos efetivamente executados, Git e hashes selecionados; não é auditoria de todos os reads/writes do sistema.
'''
(B/'FINDINGS_AND_REMEDIATION.md').write_text(findings,encoding='utf-8')
old=(P/'USER_ACCEPTANCE.md').read_text(encoding='utf-8')
table=old.split('## Doze perguntas para experimentar')[1].split('## Reconhecer problemas')[0]
table=table.replace('supply-preview-20260912','supply-final-20260912')
guide=f'''# Aceite manual — CAIN em staging

**LIMITED_IN_STAGING.** CLI/API dos seis bundles e web do acervo legado foram exercitadas. O roteiro é factual, sem precisar de modelo. Diagnósticos por regras são experimentais; os bundles reais atuais negam geração. Inferência real foi testada separadamente na CLI, com qualidade semântica não certificada.

Candidato `{cid}`; CAIN 0.4.7; Python 3.12.14 Windows; wheel SHA256 `{body['wheel_sha256']}`. Ambiente `C:/CAIN/work/supply-final-20260912/venv`; dependências exatas em `dependencies.txt`. O manifesto identifica código/contratos, corpus, política e runner. Não é um commit Git nem a instância ativa.

## Abrir e encerrar

```powershell
Set-Location 'C:\\CAIN\\work\\supply-final-20260912'
$CainPython = 'C:\\CAIN\\work\\supply-final-20260912\\venv\\Scripts\\python.exe'
& $CainPython .\\preview.py --collection crypto query --entity-type hypothesis --limit 50
```

Cada consulta encerra sozinha; Ctrl+C interrompe somente esse comando. O adaptador grava saída e erro em `USER_OBSERVATIONS.jsonl`.

Para a interface web **legada**, execute no mesmo terminal:

```powershell
& $CainPython .\\web_preview.py --legacy
```

Abra http://127.0.0.1:8889. Expanda **Pesquisa · L0 Historian**, deixe usuário `leo` e projeto `Geral`, escolha `crypto`, `stocks` ou `brasileirao` no campo Acervo e clique **Consultar acervo**. Limpe Identidade da fonte/Estado/Texto ao trocar de domínio. Abra uma evidência recebida; **Dossiê** permite navegar proveniência e datas desconhecidas. Ao recarregar, o campo retorna a `crypto`: selecione o acervo desejado novamente.

Encerre com **Ctrl+C no terminal desse servidor**. Repita o mesmo comando para recuperar o acervo. Esse início/reinício foi ensaiado. Nenhum serviço ficou ativo; Host/Origin originais e binding 127.0.0.1 foram mantidos. A web usa `model/research.db` e sua política; a CLI Bundle usa `staging/research.db`. São acervos diferentes. Não use os botões de geração como parte deste roteiro factual: o provider temporário foi encerrado.

## Acervos e limites

| Coleção | Entidades Bundle | Descritores recebidos | References |
|---|---:|---:|---:|
| crypto |20|12|0|
| brasileirao |14|2|3|
| stocks |3|0|3|
| core |16|16|0|
| ops |11|11|0|
| ecosystem |6|6|0|

O acervo Bundle tem 70 entidades, 47 descritores recebidos e 6 referências, 231658 bytes lógicos. A web legada contém 15/1/3 revisões em Crypto/Stocks/BR. Revisões não são experimentos. Stocks não recebeu preços; BR inclui relato retrospectivo, sem gerar previsão. Core/Ops/Ecosystem oferecem documentos e contratos, não todos os logs de runtime. UNKNOWN e ausência de clock histórico permanecem explícitos.

Descoberta, admissão e ingestão estão separadas em `SOURCE_INVENTORY.json`, `LEGACY_SOURCE_INVENTORY.json`, `POPULATION_PLAN.json` e `KNOWLEDGE_COVERAGE.json`. Outros paths visíveis não foram automaticamente autorizados. `ADMISSION_REQUESTS.json` registra operações pendentes de decisão administrativa; nenhum grant foi ampliado para passar um teste.

## Doze perguntas para experimentar
{table}
## Reconhecer problemas

- `total:0`/exit0 pode ser ausência no escopo. `query --entity-id ABSENT-ENGINEERING-CONTROL-20260912` é o controle de ausência; `verify` testa integridade.
- `reference_only` tem metadata, sem bytes/fetch. `received` precisa de bytes e hash verificado.
- Revogação oculta fontes/derivações; histórico legado retorna `history_redacted_by_current_policy`. Não ampliar permissões para eliminar a recusa.
- `CORRUPTION`, traceback ou exit não zero não é uma resposta factual vazia.
- Sem provider, explicação não executa inferência. Houve 3 chamadas reais bem-sucedidas e 1 timeout nesta validação; saídas reais estão em `MODEL_VERIFICATION.json` e recibos associados. Citações exatas não certificam a síntese.

Registre pergunta, resposta/referências, candidato, coleção, horário e expectativa em `USER_FEEDBACK.md` nesta pasta, mencionando a entrada de `USER_OBSERVATIONS.jsonl`. Não salve o feedback como fato científico.

## Runner finito

```powershell
& $CainPython .\\runner.py --config .\\UTILITY_PROTOCOL.json --state .\\utility-release
```

O comando foi interrompido após 2 casos e retomou até 18, preservando os resultados. Limites: 24 casos/invocação , 600 s, 45 s/subprocesso, concorrência 1, zero modelos, 2 MB por captura, 32 MB de estado e reserva 1 GiB. `utility-release/CHECKPOINT.json` já concluído é validado na retomada. Código/acervo/policy diferentes exigem revalidação e pasta nova. RAM de pico é desconhecida. Não há scheduler nem execução depois de encerrar o processo.

Recibos: `MANUAL_GUIDE_REHEARSAL.json`, `WEB_REHEARSAL.json`, `ACCEPTANCE_LEDGER.jsonl`, `INTERRUPTION_RELEASE.json`, `utility-release/CHECKPOINT.json`.
'''
(B/'USER_ACCEPTANCE.md').write_text(guide,encoding='utf-8')
handoff=f'''# CAIN Supply — entrega final para revisão

Leo pode abrir a **CLI Bundle dos seis acervos** e a **web legada de Crypto/Stocks/Brasileirão**, usando o candidato isolado em `C:/CAIN/work/supply-final-20260912`. Leia `USER_ACCEPTANCE.md`. **USER_PREVIEW_STATUS=LIMITED_IN_STAGING**; **READY_FOR_FREEZE_REVIEW=PASS no escopo de engenharia delimitado abaixo**. Nenhum congelamento administrativo, release ou implantação foi realizado.

- Candidato: `{cid}`; wheel CAIN 0.4.7 SHA256 `{body['wheel_sha256']}`. Identidade instalada: `{body['installed_code_identity']}`.
- Abrir CLI: `& 'C:/CAIN/work/supply-final-20260912/venv/Scripts/python.exe' 'C:/CAIN/work/supply-final-20260912/preview.py' --collection crypto query --entity-type hypothesis --limit 50`. Encerra sozinho.
- Abrir web: `& 'C:/CAIN/work/supply-final-20260912/venv/Scripts/python.exe' 'C:/CAIN/work/supply-final-20260912/web_preview.py' --legacy`, endereço `http://127.0.0.1:8889`. Encerrar: Ctrl+C somente nesse terminal. Portas 8889/11439 liberadas ao final.
- Perguntas: descoberta, estados literais, evidências, relações e ausências dos seis scopes; 12 comandos específicos e 18 casos do runner exercitados. UI confirmou Crypto 15, Stocks 1, BR 3 revisões, evidência e proveniência, ausência e reinício. Não é 89 experimentos: Bundle e Snapshot usam unidades diferentes.
- Runner: executado e retomado,2→18, sem duplicação. Regras, interpretação por modelo e texto de engenharia estão identificados separadamente.
- Modelo: 3 gerações locais reais com qwen3.5:0.8b, 1 timeout preservado e retry serial de 180 s. História recuperável após backup/restart; revogação redigiu o conteúdo. Citação literal passou; síntese Stocks não está totalmente apoiada. Utilidade semântica permanece inconclusiva.
- Memória derivada: comparação sintética neutra, persistência/offline restore/contradição/revogação passaram. Nenhum ganho/generalização real demonstrado; seis bundles reais continuam negando geração. Uso desabilitado por padrão.

## Código publicado e identidade exata

Branch **`{remote['branch']}`**, HEAD de publicação local e remoto **`{remote['publication_head']}`**. O último commit altera somente o README, com CI dispensado. Runtime validado no commit **`{remote['validated_runtime_head']}`**, sem alteração posterior de código ou manifesto. CI exata desse runtime: https://github.com/leonardosovienski/cain/actions/runs/{remote['run_id']}; CI de transporte: https://github.com/leonardosovienski/cain/actions/runs/{remote['baseline_ci_run_id']}. SHA conferido com `git rev-parse HEAD` e `git ls-remote origin refs/heads/{remote['branch']}`.

A raiz dessa branch contém o baseline e o kit de validação. **O runtime corrigido está no overlay verificável**, `.ci/completion/cain-overlay.zip`, associado ao PREVIEW_MANIFEST e ao manifesto de transporte `{json.loads((B/'ci-kit/CANDIDATE_MANIFEST.json').read_bytes())['candidate_id']}`. Não confundir checkout raiz/main com instalação do candidato. A CI reconstruiu bases pinadas e overlays antes de testar. Não houve merge, tag, pacote publicado, ativação permanente ou mudança global da máquina.

## Validação

| Ambiente e escopo | Resultado |
|---|---|
| Windows/Python 3.12, wheel não editável, CAIN+Bundle |575 aprovados, 1 skip de privilégio symlink|
| Linux/Python 3.11,3.12,3.13,3.14, candidato reconstruído |574 aprovados e 2 skips exclusivos de launcher Windows por versão|
| Linux segurança/POSIX direcionado |187 aprovados,zero skips,por versão; symlink obrigatório executado|
| Linux mini-auditoria |45 aprovados por versão,com sobreposição à suíte|
| Linux produtores 3.13/3.14 |Crypto23,BR11,Stocks 15 testes; ambientes/pins separados|
| Linux exportação real Snapshot |Crypto 15,Stocks 1,BR 3 revisões; ingestão/evidência/restore offline|
| Linux exportação real Bundle |Crypto 20 entidades/12 objetos,BR 14/2,Stocks 2/0; lineage e materialização offline|
| Windows acervo populado |6 scopes;47 objetos materializados/verificados; backup SQLite/CAS,restore e revogação|
| Revisão independente |Falhas corrigidas,reprobes e vínculo manifesto/overlay/wheel/fonte/instalação aprovados|

Dois skips Linux são os launchers testados no Windows; não se omitiu gate Linux obrigatório. Contagens sobrepostas não devem ser somadas. A matriz cobre consumidor/contratos/exportadores, **não** uma revalidação dos runtimes científicos completos nem todo cruzamento possível OS×Python. Stocks Linux usa o catálogo sem a seleção opcional sobre backup local; por isso 2 entidades versus 3 no bundle Windows já preservado. Não foi enviado banco científico ao CI.

`F01_F10_MATRIX.json` liga cada achado original a evidências. Proteções de paths, autorização, conflitos, variantes raw, durabilidade, quota, evidências e dependências foram exercitadas; isso não é prova universal de segurança ou tolerância a toda falha física.

## População e cobertura

O recorte preserva 70 entidades Bundle,47 descritores recebidos, 6 referências e 231658 bytes lógicos. Crypto inclui estados/trials/attestations existentes; BR inclui claims e relato retrospectivo; Stocks conserva catálogo/seleção metadata e referências; Core 16, Ops 11, Ecosystem 6 documentos/contratos. O acervo legado acrescenta 9 publicações e 19 revisões documentais, com permissões previamente existentes.

Inventário de paths dos seis repositórios e publicações admitidas está preservado; denominador científico completo UNKNOWN. Não houve varredura indiscriminada de discos, nova previsão, liquidação, backtest, treino, trade, aposta ou promoção de métrica. Novas admissões estão registradas em ADMISSION_REQUESTS; geraçãofalse dos documentos exportados conservadoramente não é uma proibição universal inferida de licença.

## Preservação e autoria

Os sete checkouts originais mantiveram HEAD/status e hashes selecionados (`SOURCE_PRESERVATION.json`). Mudanças CAIN ocorreram em cópia isolada. Stocks recebeu somente uma fixture de portabilidade em overlay na raiz própria; Core/Ops runtime não mudaram. Preservação se baseia nos comandos,Git e hashes observados, não em auditoria de kernel. A tentativa inicial antiga de hash amplo foi interrompida sem log por read; não há alegação de zero acesso a toda classe restrita.

O CAIN produziu consultas/regras e gerações registradas; o Codex produziu código,harness,oráculos e este relatório. Persistência de resultados não é aprendizado. Modelos não decidem validade científica nem autorizam operações. A interpretação não apoiada e os resultados negativos foram conservados.

## Reconstrução e retomada sem chat

Bases dos sete projetos,arquivos alterados,patch,overlay,wheel,dependências,corpus,policy e runner estão em CANDIDATE_MANIFEST.json. `overlay.zip` preserva bytes inclusive CRLF; cenários/rubricas originais são byte-idênticos. Reconstrução CAIN foi ensaiada em `reconstruction-check`:

```powershell
& 'C:/CAIN/work/supply-final-20260912/venv/Scripts/python.exe' 'C:/CAIN/work/supply-final-20260912/restore_working_tree.py' --destination 'C:/CAIN/work/NOVO_DESTINO'
```

O destino deve ser novo. O script reconstrói CAIN; a fixture Stocks está separada em `C:/STOCKS/work/supply-portability-20260912/tools/test_cain_bundle_selection.py` e `ci-kit/stocks-overlay.zip`. `ci-kit/prepare_ci.py` e `restore_candidate.py` reconstroem os checkouts para Linux a partir das bases/overlays declarados. Não usar reset/clean sobre fontes originais.

Runner: `& 'C:/CAIN/work/supply-final-20260912/venv/Scripts/python.exe' 'C:/CAIN/work/supply-final-20260912/runner.py' --config 'C:/CAIN/work/supply-final-20260912/UTILITY_PROTOCOL.json' --state 'C:/CAIN/work/supply-final-20260912/utility-release'`. A execução já terminou; retomada valida os 18 resultados. Config/código/policy diferentes exigem pasta nova e revalidação. Nenhum trabalho continua em background após esta entrega.

Artefatos principais: BASELINE/SESSION_BASELINE; SOURCE_INVENTORY e LEGACY_SOURCE_INVENTORY; POPULATION_PLAN/LEDGER; KNOWLEDGE_COVERAGE; UTILITY_PROTOCOL/RESULTS; DERIVED_VALIDATION; FINDINGS_AND_REMEDIATION; GATES; CHECKPOINT; USER_ACCEPTANCE. Evidências novas: FINAL_VERIFICATION,REMOTE_FINAL_VERIFICATION,MODEL_VERIFICATION,WEB_REHEARSAL,MANUAL_GUIDE_REHEARSAL,diagnostic-restore,derived-evaluation-r2,linux-final-*. Revisão independente original em `C:/CAIN/work/supply-review-20260912/DELIVERY_REVIEW.md`.

Não resta defeito reproduzível aberto no escopo revisado. Uma revisão humana pode agora decidir o congelamento **da Supply delimitada**, conservando as limitações de conteúdo/modelo e a derivação experimental desligada. A entrega não autoriza freeze administrativo nem implantação. Para ampliar o produto, decidir admissões específicas e avaliar benefício semântico em protocolo próprio, sem tratar esta fundação como lucro ou aprendizado validado.

## Gates separados

```json
{json.dumps(gates,ensure_ascii=False,indent=2)}
```

Os limites de interpretação de cada gate constam de GATES.json. PASS de pipeline derivado refere-se ao mecanismo testado, não à geração negada nos seis bundles reais; PASS de integridade científica refere-se à evidência observável declarada acima.
'''
(B/'FINAL_HANDOFF.md').write_text(handoff,encoding='utf-8')
check=dict(status='FINITE_EXECUTION_COMPLETE',candidate=cid,remote=remote['publication_head'],validated_runtime_head=remote['validated_runtime_head'],gates=gates,
 corpus=body['corpus_bundles'],completed_cases=list(checkpoint['completed']),
 pending=['Administrative freeze/deployment intentionally not executed','Source-specific admission for broader corpus or real Bundle derivation','Real semantic/derived benefit remains inconclusive'],
 next_safe_action='Open USER_ACCEPTANCE for manual feedback; human freeze review of the bounded candidate',
 consumption=dict(runner_bytes=v['runner']['bytes'],model_successes=3,model_failures=1,peak_ram='UNKNOWN',persistent_services=False),
 evidence_root=str(B))
(B/'CHECKPOINT.json').write_text(json.dumps(check,indent=2))
history=O/'historico-antes-do-final';history.mkdir(exist_ok=True)
for name in ('USER_ACCEPTANCE.md','FINAL_HANDOFF.md','CONTINUACAO_EXECUTADA.md'):
 if (O/name).exists() and not (history/name).exists():shutil.copyfile(O/name,history/name)
for name in ('USER_ACCEPTANCE.md','FINAL_HANDOFF.md','FINDINGS_AND_REMEDIATION.md','GATES.json','CHECKPOINT.json'):
 shutil.copyfile(B/name,O/name)
(O/'CONTINUACAO_EXECUTADA.md').write_text('# Continuidade final\n\nEsta rodada foi concluída. Consulte [o handoff final](FINAL_HANDOFF.md) e [o guia manual](USER_ACCEPTANCE.md). Os relatórios anteriores foram preservados em historico-antes-do-final.\n',encoding='utf-8')
index={p.relative_to(B).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in B.iterdir() if p.is_file() and p.name!='DELIVERY_INDEX.json'}
(B/'DELIVERY_INDEX.json').write_text(json.dumps(index,indent=2))
print(json.dumps(dict(candidate=cid,ready_for_freeze_review=gates['READY_FOR_FREEZE_REVIEW'],outputs=str(O))))
