import json,pathlib,hashlib
from cain.evaluation.resources import installed_identity
B=pathlib.Path(__file__).parent
plan=json.loads((B/'POPULATION_PLAN.json').read_bytes())
cases=[]
for domain,root in plan['exports'].items():
 bundle=json.loads((pathlib.Path(root)/'bundle.json').read_bytes())
 for kind,args,expected,question,purpose in [
 ('discover',['query','--limit','50'],{'total':len(bundle['entities'])},'Que registros existem neste acervo?','Descobrir entidades sem conhecer IDs; inspecionar fontes e status.'),
 ('lineage',['lineage','--limit','50'],{'total':len(bundle['relations'])},'Quais relações foram declaradas pelas fontes?','Inspecionar relações explícitas; não inferir causalidade.'),
 ('missing',['query','--entity-id','ABSENT-ENGINEERING-CONTROL-20260912'],{'total':0},'Existe o registro ABSENT-ENGINEERING-CONTROL-20260912?','Distinguir ausência esperada de erro de armazenamento.')]:
  cases.append(dict(case_id=domain+'-'+kind,collection=domain,split='development' if kind=='discover' else 'final',question=question,purpose=purpose,args=args,expected=expected,oracle='Original validated producer bundle, independent of CAIN index',source_evidence=bundle['bundle_id'],known_unknowns=bundle['coverage']['limitations']))
config=dict(schema='cain-finite-harness/1',db=str(B/'staging/research.db'),policy=str(B/'staging/policy.json'),collections=list(plan['exports']),cases=cases,max_cases_per_run=24,max_seconds=600,subprocess_seconds=45,max_output_bytes=2000000,max_run_bytes=32000000,max_cardinality=1000,reserve_bytes=1073741824,model_calls=0,concurrency=1)
config.update(expected_code=installed_identity()['source_tree_sha256'],expected_policy=hashlib.sha256((B/'staging/policy.json').read_bytes()).hexdigest())
(B/'UTILITY_PROTOCOL.json').write_text(json.dumps(config,indent=2),encoding='utf-8')
(B/'UTILITY_PROTOCOL.sha256').write_text(hashlib.sha256((B/'UTILITY_PROTOCOL.json').read_bytes()).hexdigest())
print('Protocol frozen before execution: 18 cases, 6 development / 12 final; same executor, not blind.')
