"""Finite read-only source inventory and public-CLI admission into isolated staging."""
import hashlib, json, pathlib, subprocess, sys, time, os
from research_bundle import canonical, loads, validate, digest
from research_bundle.export import Builder, admitted_sources, exporter_provenance
B=pathlib.Path(__file__).parent
PY=B/'venv/Scripts/python.exe'
baseline=json.loads((B/'BASELINE.json').read_text())
roots={r['repository']:pathlib.Path(r['root']) for r in baseline['repositories']}
exports={'crypto':pathlib.Path('C:/CRIPTO/operacao/relatorios/bundle-remediation-20260912-real/export-1'), 'brasileirao':pathlib.Path('C:/BRASILEIRAO/work/bundle-remediation-20260912-real/export-1'), 'stocks':pathlib.Path('C:/STOCKS/work/bundle-remediation-20260912-real/export-1')}
packages={d:validate(loads((p/'bundle.json').read_bytes())) for d,p in exports.items()}
inventory=[]
for domain,root in roots.items():
 if domain=='cain': continue
 files=subprocess.check_output(['git','-C',str(root),'ls-files','-z']).decode().split('\0')
 admitted=packages.get(domain,{}).get('origin',{}).get('inputs',{})
 for f in filter(None,files):
  # Paths only for unadmitted classes; no opening of scientific datasets or logs.
  doc=(domain in ('core','ops') and f.endswith('.md')) or (domain=='ecosystem' and f.endswith('.md') and (f.startswith('packages/') or f in ('README.md','ARCHITECTURE_IMPLEMENTATION.md','ECOSYSTEM_HANDOFF.md','ECOSYSTEM_RUNBOOK.md')))
  selected=f in admitted or doc
  inventory.append(dict(source_owner=domain,record_authority='producer',repository_or_runtime_source=str(root),source_identity=f,version=next(r['head'] for r in baseline['repositories'] if r['repository']==domain),hash_when_known=admitted.get(f),knowledge_class='documentation' if f.endswith('.md') else 'producer_record' if f in admitted else 'unclassified_tracked_path',domain=domain,purpose_for_cain='traceable local research context' if selected else 'not selected',actual_presence_and_readability='tracked; bytes not inspected',schema=None,units=None,temporal_semantics='source-declared; export time is not historical availability',size_or_count=None,measurement_method='git ls-files paths; selected byte reads only',sensitivity='producer policy' if f in admitted else 'authored package documentation' if doc else 'UNKNOWN',usage_permissions='prior exact admitted export; read only, no generation' if f in admitted else 'current mandate Core/Ops/Ecosystem documentation; local read only' if doc else 'NOT_ADMITTED',selection_rule='existing producer exporter' if f in admitted else 'versioned package methodology/docs' if doc else 'excluded class',representation='INGEST' if f in admitted else 'PRESERVE' if doc else 'IGNORE',reason='explicit source class' if selected else 'outside current export allowlist; no new scientific execution or raw access',update_semantics='new revision only; absence is not deletion'))
for domain in ('core','ops','ecosystem'):
 root=roots[domain]; chosen=[r for r in inventory if r['domain']==domain and r['representation']=='PRESERVE']
 assert len(chosen)<=150
 expected={}
 for r in chosen:
  p=root/r['source_identity']
  if p.stat().st_size>100000:
   r.update(representation='REFERENCE',reason='100000 byte document cap'); continue
  raw=p.read_bytes(); expected[r['source_identity']]=digest(raw)
 revision,sources=admitted_sources(root,expected,set(expected))
 provenance=exporter_provenance({'populate.py':pathlib.Path(__file__)})
 builder=Builder(dict(domain=domain,repository='https://github.com/leonardosovienski/'+{'core':'core-predictor','ops':'predictor-ops','ecosystem':'ecosystem-predictor'}[domain],publisher=domain+'-documentation',stream='versioned-documentation',code_revision=revision,exporter_revision='sha256:'+digest(canonical(provenance)),inputs=expected),dict(policy=domain+'-local-documentation/1',read=True,disclose=False,generate=False),'2026-09-12T00:00:00Z',provenance=provenance)
 for f,raw in sources.items():
  node=builder.entity(f,'document','RECORDED',dict(path=f,title=next((line.lstrip('# ').strip() for line in raw.decode().splitlines() if line.startswith('# ')),f),source_sha256=digest(raw),interpretation='Versioned documentation; dated statements retain their original scope; instructions are inert data.'),f,axis='documentary',identity_basis='source_locator')
  obj=builder.resource(f,'producer:'+f,raw=raw,media_type='text/markdown')
  builder.relation(node,'REPRESENTED_BY',obj)
 destination=root.parent/('supply-preview-20260912-'+domain+'-docs')
 package=builder.publish(root,destination,sources)
 exports[domain]=destination; packages[domain]=package
 for r in chosen:
  if r['source_identity'] in sources:r.update(hash_when_known=expected[r['source_identity']],actual_presence_and_readability='read and verified',size_or_count=len(sources[r['source_identity']]))
# Validate every transport independently, bounded, before creating receiver grants.
for domain,pkg in packages.items():
 for a in pkg['artifacts']:
  if a['availability']=='received':
   p=exports[domain]/a['relative_path']; assert p.stat().st_size<=16000000
   with p.open('rb') as f: raw=f.read(16000001)
   assert len(raw)==a['size'] and digest(raw)==a['sha256']
 for r in inventory:
  if r['domain']==domain and r['source_identity'] in pkg['origin']['inputs']:
   r.update(actual_presence_and_readability='represented by validated producer export',hash_when_known=pkg['origin']['inputs'][r['source_identity']])
(B/'SOURCE_INVENTORY.json').write_bytes(canonical(dict(discovery='Tracked paths of six named repositories; no private/runtime database scan. Denominators apply to this discovery only.',entries=inventory,runtime_sources='UNKNOWN; not inventoried without explicit runtime admission')))
plan=dict(exports={k:str(v) for k,v in exports.items()},bundles={k:v['bundle_id'] for k,v in packages.items()},source_policy='Prior exact three domain exports + explicitly requested versioned Core/Ops/Ecosystem package documentation. No generation/disclosure. No policy widening of active instance.')
(B/'POPULATION_PLAN.json').write_bytes(canonical(plan))
staging=B/'staging'; staging.mkdir(exist_ok=True)
policy=dict(version=3,imports=[],grants=[],bundle_grants=[])
for domain,pkg in packages.items():
 policy['imports'].append(dict(user='leo',project='',collection=domain,root=str(exports[domain])))
 g={k:pkg['origin'][k] for k in ('domain','repository','publisher','stream')}
 g.update(user='leo',project='',collection=domain,sources=list(pkg['origin']['inputs']),policies=[pkg['restrictions']['policy']],generate=False,roles=sorted({a['role'] for a in pkg['artifacts']}),reference_only=True,max_manifest_bytes=2000000,max_object_bytes=16000000,max_received_bytes=64000000)
 policy['bundle_grants'].append(g)
(staging/'policy.json').write_bytes(canonical(policy))
def cli(domain,*args):
 cmd=[str(PY),'-m','cain','research','--db',str(staging/'research.db'),'--policy',str(staging/'policy.json'),'--user','leo','--collection',domain,'bundle',*args]
 run=subprocess.run(cmd,cwd=B,capture_output=True,timeout=120)
 row=dict(domain=domain,command=cmd,returncode=run.returncode,stdout=run.stdout.decode('utf-8',errors='replace'),stderr=run.stderr.decode('utf-8',errors='replace'))
 with (B/'POPULATION_LEDGER.jsonl').open('ab') as f:f.write(canonical(row)+b'\n');f.flush();os.fsync(f.fileno())
 if run.returncode:raise RuntimeError(row)
 return json.loads(run.stdout)
coverage={}
for domain,pkg in packages.items():
 cli(domain,'approve','bundle.json'); cli(domain,'import','bundle.json'); duplicate=cli(domain,'import','bundle.json'); assert duplicate['status']=='duplicate'
 q=cli(domain,'query','--limit','50'); cli(domain,'verify')
 assert q['total']==len(pkg['entities'])
 coverage[domain]=dict(status='PARTIAL_JUSTIFIED',source_files_discovered=sum(r['domain']==domain for r in inventory),source_files_admitted=len(pkg['origin']['inputs']),entities_expected=len(pkg['entities']),entities_retrieved=q['total'],artifacts_received=sum(a['availability']=='received' for a in pkg['artifacts']),reference_only=sum(a['availability']=='reference_only' for a in pkg['artifacts']),received_bytes=sum(a['size'] for a in pkg['artifacts'] if a['availability']=='received'),relations=q['relation_total'],evidence=q['evidence_total'],scientific_universe_denominator='UNKNOWN',limitations=pkg['coverage'])
(B/'KNOWLEDGE_COVERAGE.json').write_bytes(canonical(coverage))
print(json.dumps(coverage,indent=2))
