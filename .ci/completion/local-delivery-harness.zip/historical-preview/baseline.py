import hashlib, json, pathlib, subprocess, shutil, datetime
B=pathlib.Path(__file__).parent
old=json.loads(pathlib.Path('C:/CAIN/work/bundle-linux-validation-20260912/CANDIDATE_MANIFEST.json').read_text())
def git(root,*args): return subprocess.check_output(['git','-C',str(root),*args])
def sha(raw): return hashlib.sha256(raw).hexdigest()
identity=[{k:r[k] for k in ('repository','base_head','branch','file_hashes','package_metadata')} for r in old['repositories']]
assert sha(json.dumps(identity,sort_keys=True,separators=(',',':')).encode())==old['candidate_id']
rows=[]
for r in old['repositories']:
 root=pathlib.Path(r['root']); files=sorted(set(r['file_hashes'])|{'pyproject.toml'}); hashes={f:sha((root/f).read_bytes()) for f in files if f and (root/f).is_file()}
 rows.append(dict(repository=r['repository'],root=str(root),head=git(root,'rev-parse','HEAD').decode().strip(),branch=git(root,'branch','--show-current').decode().strip(),status=git(root,'status','--porcelain').decode(),tracked_hashes=hashes,prior_comparison={f:hashes.get(f)==h for f,h in r['file_hashes'].items()}))
out=dict(captured_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),original_manifest_identity_verified=True,original_candidate=old['candidate_id'],repositories=rows,limits=dict(rounds=8,model_calls=0,concurrency=1,subprocess_seconds=600,staging_bytes=268435456,reserve_bytes=1073741824))
(B/'BASELINE.json').write_text(json.dumps(out,indent=2))
(B/'SESSION_BASELINE.md').write_text('# Baseline\n\nOriginal manifest identity independently recomputed: PASS. All seven checkout trees preserved; no reset/clean. Selected prior-manifest byte hashes and package metadata in BASELINE.json. Initial full tracked hash attempt stopped before completion; no output or mutations from it.\n\n'+ '\n'.join(f"- {r['repository']}: {r['root']}, HEAD {r['head']}, dirty={bool(r['status'])}; old selected bytes equal {sum(r['prior_comparison'].values())}/{len(r['prior_comparison'])}" for r in rows)+'\n\nActive databases were not opened. Staging will have separate databases/CAS. Prior Linux CI failed installed resources; local WSL unavailable. Finite limits in BASELINE.json.\n',encoding='utf-8')
src=pathlib.Path(old['repositories'][0]['root']); dst=B/'candidate'
dst.mkdir()
for f in git(src,'ls-files','-z').decode().split('\0'):
 if f and (src/f).is_file():
  target=dst/f; target.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(src/f,target)
print(json.dumps({r['repository']:r['prior_comparison'] for r in rows},indent=2))
