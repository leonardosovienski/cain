import pytest
from research_bundle import canonical
from cain.research import ResearchService
from cain.research.diagnostics import Diagnostics
import test_research_bundle


@pytest.fixture
def setup(tmp_path):
    return test_research_bundle.setup.__wrapped__(tmp_path)


def test_restart_idempotence_and_revocation(setup):
    bundles, scope, _, _, path, policy = setup
    bundles.ingest('one/bundle.json', scope)
    first = Diagnostics(bundles.service).create(scope)
    assert first['total'] == 1
    assert first['diagnostics'][0]['assertion']['received'] == 1
    assert Diagnostics(ResearchService(bundles.service.path, path)).create(scope) == first
    policy['bundle_grants'][0]['generate'] = False
    path.write_bytes(canonical(policy))
    with pytest.raises(PermissionError, match='NOT_AUTHORIZED_FOR_DERIVATION'):
        Diagnostics(bundles.service).list(scope)


def test_role_revocation_hides_old_diagnostic(setup):
    bundles, scope, _, _, path, policy = setup
    bundles.ingest('one/bundle.json', scope)
    assert Diagnostics(bundles.service).create(scope)['total'] == 1
    policy['bundle_grants'][0]['roles'] = []
    path.write_bytes(canonical(policy))
    assert Diagnostics(bundles.service).list(scope)['total'] == 0


def test_other_scope_cannot_read_diagnostics(setup):
    bundles, scope, _, _, _, _ = setup
    bundles.ingest('one/bundle.json', scope)
    Diagnostics(bundles.service).create(scope)
    with pytest.raises(PermissionError):
        Diagnostics(bundles.service).list(bundles.service.scope('other', None, 'a'))
